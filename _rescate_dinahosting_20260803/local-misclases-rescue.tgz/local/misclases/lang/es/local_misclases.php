<?php
defined('MOODLE_INTERNAL') || die();
$string['pluginname'] = 'Mis Clases';
$string['misclases'] = 'Mis Clases';
$string['misclases:view'] = 'Ver mis clases';
