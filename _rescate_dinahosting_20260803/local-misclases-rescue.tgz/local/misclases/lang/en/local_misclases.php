<?php
defined('MOODLE_INTERNAL') || die();
$string['pluginname'] = 'My Classes';
$string['misclases'] = 'My Classes';
$string['misclases:view'] = 'View my classes';
