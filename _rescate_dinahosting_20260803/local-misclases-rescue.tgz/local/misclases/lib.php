<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Añade "Mis Clases" a la navegación principal para todos los usuarios logueados
 */
function local_misclases_extend_navigation(global_navigation $navigation) {
    global $USER, $PAGE, $CFG;

    $demo_users = [
        'aldiaz@velcro.com', 'brodriguez@velcro.com', 'mlinan@velcro.com',
        'sherrera@velcro.com', 'ddroege@velcro.com',
        'demo.cenieh', 'demo.mar.abgcc', 'demo.natalia.victoria', 'demo.test.company',
        'demo.pamesa', 'demo.cap.capital', 'demo.rg.iberia', 'demo.new.lush',
        'demo.manusa', 'demo.fritermia', 'demo.salva', 'demo.ambit', 'demo.envases',
        'demo.casas', 'demo.unitedit', 'demo.antonpaar', 'demo.dermik', 'demo.totem',
        'demo.aarus', 'demo.ivi', 'demo.abionica', 'demo.novasonic', 'demo.ibeforum',
        'demo.ironhack', 'demo.biopharma', 'demo.metalco', 'demo.tradisa',
        'demo.synergie', 'demo.adecco.new'
    ];

    if (isloggedin() && !isguestuser() && in_array($USER->username, $demo_users)) {
        if ($PAGE->pagetype === 'my-index') {
            redirect(new moodle_url('/portal/demo_welcome.php'));
        }
    }

    if (isloggedin() && !isguestuser()) {
        $node = $navigation->add(
            get_string('pluginname', 'local_misclases'),
            new moodle_url('/misclases.php'),
            navigation_node::TYPE_CUSTOM,
            null,
            'local_misclases',
            new pix_icon('i/calendar', '')
        );
        $node->showinflatnavigation = true;
    }
}

/**
 * Añade "Mis Clases" al menú del perfil de usuario
 */
function local_misclases_extend_navigation_user_settings($navigation, $user, $context, $course, $coursecontext) {
    global $USER;
    
    if ($user->id == $USER->id || is_siteadmin()) {
        $navigation->add(
            get_string('pluginname', 'local_misclases'),
            new moodle_url('/misclases.php', ['userid' => $user->id]),
            navigation_node::TYPE_SETTING
        );
    }
}

/**
 * Añade enlaces en el bloque de navegación del curso:
 * - "Mis Clases" (todos los cursos)
 * - "Tutorías con profesor" (solo cursos 1TO1, con datos de Zoom)
 * 
 * Modificado 2026-05-25: añadido enlace automático a tutorias_con_profesor.php
 * para cursos 1TO1. Consulta own_acuity_course.tipo_clase.
 * Backup: lib.php.bak_20260525_tutorias
 */
function local_misclases_extend_navigation_course($navigation, $course, $context) {
    global $USER;
    
    if (isloggedin() && !isguestuser()) {
        // Enlace "Mis Clases" (existente, todos los cursos)
        $navigation->add(
            get_string('pluginname', 'local_misclases'),
            new moodle_url('/misclases.php', ['courseid' => $course->id]),
            navigation_node::TYPE_CUSTOM,
            null,
            'local_misclases_course',
            new pix_icon('i/calendar', '')
        );
        
        // Enlace "Tutorías con profesor" (solo cursos 1TO1)
        try {
            $pdo = new PDO(
                "mysql:host=localhost;dbname=aulatuspeaking35;charset=utf8mb4",
                "moodle35",
                "TuspeakingFix2025!"
            );
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $pdo->prepare("SELECT tipo_clase FROM own_acuity_course WHERE courseid = ? LIMIT 1");
            $stmt->execute([$course->id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($row && $row['tipo_clase'] === '1TO1') {
                $navigation->add(
                    'Tutorías con profesor',
                    new moodle_url('/tutorias_con_profesor.php', ['courseid' => $course->id]),
                    navigation_node::TYPE_CUSTOM,
                    null,
                    'local_tutorias_profesor',
                    new pix_icon('i/report', '')
                );
            }
        } catch (Exception $e) {
            // Silenciar errores de BD para no romper la navegación
            // Si falla, simplemente no aparece el enlace
        }
    }
}

/**
 * Redirige usuarios demo/velcro al portal de bienvenida tras el login
 */
function local_misclases_after_config() {
    global $USER, $CFG;

    $demo_users = [
        'aldiaz@velcro.com', 'brodriguez@velcro.com', 'mlinan@velcro.com',
        'sherrera@velcro.com', 'ddroege@velcro.com',
        'demo.cenieh', 'demo.mar.abgcc', 'demo.natalia.victoria', 'demo.test.company',
        'demo.pamesa', 'demo.cap.capital', 'demo.rg.iberia', 'demo.new.lush',
        'demo.manusa', 'demo.fritermia', 'demo.salva', 'demo.ambit', 'demo.envases',
        'demo.casas', 'demo.unitedit', 'demo.antonpaar', 'demo.dermik', 'demo.totem',
        'demo.aarus', 'demo.ivi', 'demo.abionica', 'demo.novasonic', 'demo.ibeforum',
        'demo.ironhack', 'demo.biopharma', 'demo.metalco', 'demo.tradisa',
        'demo.synergie', 'demo.adecco.new'
    ];

    if (!isloggedin() || isguestuser()) return;
    if (!in_array($USER->username, $demo_users)) return;

    $current = $_SERVER['REQUEST_URI'] ?? '';
    $welcome = '/app/moodle/portal/demo_welcome.php';

    // Solo redirigir si están en /my/ (dashboard por defecto tras login)
    if (strpos($current, '/my/') !== false || $current === '/app/moodle/' || $current === '/app/moodle') {
        header('Location: ' . $CFG->wwwroot . '/portal/demo_welcome.php');
        exit;
    }
}


/**
 * Inyecta CSS para ocultar breadcrumb en usuarios demo
 */
function local_misclases_before_footer() {
    global $USER;

    $demo_users = [
        'aldiaz@velcro.com', 'brodriguez@velcro.com', 'mlinan@velcro.com',
        'sherrera@velcro.com', 'ddroege@velcro.com',
        'demo.cenieh', 'demo.mar.abgcc', 'demo.natalia.victoria', 'demo.test.company',
        'demo.pamesa', 'demo.cap.capital', 'demo.rg.iberia', 'demo.new.lush',
        'demo.manusa', 'demo.fritermia', 'demo.salva', 'demo.ambit', 'demo.envases',
        'demo.casas', 'demo.unitedit', 'demo.antonpaar', 'demo.dermik', 'demo.totem',
        'demo.aarus', 'demo.ivi', 'demo.abionica', 'demo.novasonic', 'demo.ibeforum',
        'demo.ironhack', 'demo.biopharma', 'demo.metalco', 'demo.tradisa',
        'demo.synergie', 'demo.adecco.new'
    ];

    if (!isloggedin() || isguestuser()) return;
    if (!in_array($USER->username, $demo_users)) return;

    echo '<style>#page-header-nav.clearfix { display: none !important; }</style>';
}
