<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_misclases';
$plugin->version = 2026052501;
