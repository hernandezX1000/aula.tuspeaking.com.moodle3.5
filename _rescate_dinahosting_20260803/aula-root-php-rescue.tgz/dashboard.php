<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Centro de Mando - tuSpeaking</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header><h1>Centro de Mando - tuSpeaking</h1></header>
    <nav>
        <ul>
            <li><a href="modulos/panel.php">📊 Panel de Seguimiento</a></li>
            <li><a href="modulos/prueba_nivel.php">🧪 Asignación automática de prueba de nivel</a></li>
            <li><a href="modulos/altas_masivas.php">👥 Alta masiva de usuarios</a></li>
            <li><a href="modulos/reportes.php">📈 Reportes de progreso y clases</a></li>
            <li><a href="modulos/export_fundae.php">📤 Exportación FUNDAE</a></li>
            <li><a href="modulos/zoom_asistencia.php">📅 Gestión de Zoom y asistencia</a></li>
            <li><a href="modulos/chatbot.php">💬 Chatbot educativo</a></li>
            <li><a href="logout.php">🔓 Cerrar sesión</a></li>
        </ul>
    </nav>
    <main>
        <p>Selecciona un módulo del menú.</p>
    </main>
</body>
</html>
