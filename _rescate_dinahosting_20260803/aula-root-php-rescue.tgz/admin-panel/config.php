<?php
/**
 * Configuración del Panel de Administración
 * TuSpeaking
 */

// Base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'aulatuspeaking35');
define('DB_USER', 'moodle35');
define('DB_PASS', 'TuspeakingFix2025!');

// Rutas
define('PANEL_PATH', '/home/aulatuspeaking/www/app/moodle/admin-panel');
define('PANEL_URL', '/app/moodle/admin-panel');
define('MOODLE_URL', '/app/moodle');

// Caché
define('CACHE_TIME', 60); // segundos

// Moodle URLs base
define('MOODLE_ADMIN', MOODLE_URL . '/admin');
define('MOODLE_COURSE', MOODLE_URL . '/course');
define('MOODLE_USER', MOODLE_URL . '/user');

// Archivo de herramientas
define('TOOLS_FILE', PANEL_PATH . '/tools.json');

// Pendientes (para mostrar en panel)
$GLOBALS['pendientes'] = array(
    'LinkedIn cuenta 2 - URL por definir',
    'LinkedIn Ads - URL por definir',
    'Sistema Evaluaciones - En desarrollo',
    'Reportes configurables - Por depurar',
);
