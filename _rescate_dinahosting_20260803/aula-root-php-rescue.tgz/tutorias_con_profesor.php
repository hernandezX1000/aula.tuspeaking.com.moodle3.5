<?php
/**
 * tutorias_con_profesor.php
 * 
 * Registro de tutorías con profesor para auditoría FUNDAE.
 * Muestra datos de trazabilidad Zoom: participantes, hora entrada/salida,
 * duración real, ID de reunión, por sesión.
 * 
 * Parámetros:
 *   - courseid (requerido): ID del curso Moodle
 *   - userid (opcional): ID del alumno (default: usuario actual)
 * 
 * Accesible para: student (propio), teacher, supervisor, admin
 * 
 * Ubicación: /home/aulatuspeaking/.ftp-users/moodle/tutorias_con_profesor.php
 * 
 * @package    local
 * @author     tuSpeaking Platform
 * @copyright  2026 Micro Ventures S.L.
 */

require_once('config.php');
require_login();
global $USER, $DB, $PAGE, $OUTPUT;

$courseid = required_param('courseid', PARAM_INT);
$view_userid = optional_param('userid', 0, PARAM_INT); // 0 = auto-detectar
$export = optional_param('export', '', PARAM_ALPHA);

// Verificar que el curso existe
$course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
$context = context_course::instance($courseid);

// Verificar permisos: el usuario debe estar matriculado en el curso
// o ser admin del sitio
$is_admin = is_siteadmin();
$is_enrolled = is_enrolled($context, $USER, '', true);
if (!$is_admin && !$is_enrolled) {
    print_error('nopermissions', 'error', '', 'ver tutorías de este curso');
}

// Determinar rol del usuario actual en el curso
$user_roles = get_user_roles($context, $USER->id, true);
$supervisor_roles = ['teacher', 'editingteacher', 'supervisor', 'manager'];
$is_supervisor = $is_admin;
foreach ($user_roles as $role) {
    if (in_array($role->shortname, $supervisor_roles)) {
        $is_supervisor = true;
        break;
    }
}

// Auto-detección de alumno cuando no se pasa userid
if ($view_userid == 0) {
    if (!$is_supervisor) {
        // Es alumno: mostrar sus propios datos
        $view_userid = $USER->id;
    } else {
        // Es supervisor/teacher/admin: buscar alumnos del curso con rol student
        $student_role = $DB->get_record('role', ['shortname' => 'student']);
        $students = [];
        if ($student_role) {
            $enrolled_students = get_role_users($student_role->id, $context, false, 'u.id, u.firstname, u.lastname, u.email', 'u.lastname ASC');
            $students = $enrolled_students ? array_values($enrolled_students) : [];
        }
        
        if (count($students) == 1) {
            // Solo un alumno: mostrar directamente sus datos
            $view_userid = $students[0]->id;
        } elseif (count($students) > 1) {
            // Varios alumnos: mostrar selector
            $PAGE->set_url('/tutorias_con_profesor.php', ['courseid' => $courseid]);
            $PAGE->set_context($context);
            $PAGE->set_course($course);
            $PAGE->set_title('Tutorías con profesor - Seleccionar alumno');
            $PAGE->set_heading('Tutorías con profesor');
            $PAGE->set_pagelayout('incourse');
            echo $OUTPUT->header();
            echo '<div style="max-width:800px;margin:0 auto;padding:20px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif">';
            echo '<a href="' . $CFG->wwwroot . '/course/view.php?id=' . $courseid . '" style="color:#008ba3;text-decoration:none;font-weight:500">← Volver al curso</a>';
            echo '<h2 style="color:#424242;margin:20px 0 8px">📋 Tutorías con profesor</h2>';
            echo '<p style="color:#64748b;margin-bottom:24px">' . htmlspecialchars($course->fullname) . '</p>';
            echo '<h3 style="color:#424242;border-bottom:2px solid #e2e8f0;padding-bottom:12px">Selecciona un alumno</h3>';
            foreach ($students as $s) {
                $url = $CFG->wwwroot . '/tutorias_con_profesor.php?courseid=' . $courseid . '&userid=' . $s->id;
                echo '<a href="' . $url . '" style="display:block;background:#fff;border:1px solid #e2e8f0;border-left:4px solid #008ba3;border-radius:8px;padding:16px 20px;margin:8px 0;text-decoration:none;transition:all .2s">';
                echo '<strong style="color:#424242;display:block">' . fullname($s) . '</strong>';
                echo '<span style="color:#64748b;font-size:.85em">' . $s->email . '</span>';
                echo '</a>';
            }
            echo '</div>';
            echo $OUTPUT->footer();
            exit;
        } else {
            // Sin alumnos
            $view_userid = $USER->id;
        }
    }
}

// Si no es admin ni el propio usuario, verificar que tenga rol teacher/supervisor
if (!$is_admin && $view_userid != $USER->id && !$is_supervisor) {
    print_error('nopermissions', 'error', '', 'ver tutorías de otro usuario');
}

$view_user = $DB->get_record('user', ['id' => $view_userid], '*', MUST_EXIST);

$PAGE->set_url('/tutorias_con_profesor.php', ['courseid' => $courseid, 'userid' => $view_userid]);
$PAGE->set_context($context);
$PAGE->set_course($course);
$PAGE->set_title('Tutorías con profesor - ' . $course->fullname);
$PAGE->set_heading('Tutorías con profesor');
$PAGE->set_pagelayout('incourse');

// Conexión PDO directa (igual que misclases.php)
$pdo = new PDO(
    "mysql:host=localhost;dbname=aulatuspeaking35;charset=utf8mb4",
    "moodle35",
    "TuspeakingFix2025!"
);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// ─── QUERY 1: Resumen de asistencia del alumno en el curso ───
$sql_resumen = "
    SELECT 
        user_id,
        course_id,
        course_name,
        company_name,
        clases_asistidas,
        clases_agendadas,
        porcentaje_asistencia,
        minutos_totales,
        primera_clase,
        ultima_clase
    FROM v_zoom_asistencia_estudiantes
    WHERE user_id = ? AND course_id = ?
";
$stmt_resumen = $pdo->prepare($sql_resumen);
$stmt_resumen->execute([$view_userid, $courseid]);
$resumen = $stmt_resumen->fetch(PDO::FETCH_ASSOC);

// ─── QUERY 2: Detalle de clases (vista general con estados) ───
$sql_detalle = "
    SELECT 
        fecha,
        hora_agendada,
        hora_real,
        estado,
        minutos,
        profesor,
        profesor_conecto
    FROM v_zoom_detalle_clases
    WHERE course_id = ? AND user_id = ?
    ORDER BY STR_TO_DATE(fecha, '%d/%m/%Y') ASC
";
$stmt_detalle = $pdo->prepare($sql_detalle);
$stmt_detalle->execute([$courseid, $view_userid]);
$detalle_clases = $stmt_detalle->fetchAll(PDO::FETCH_ASSOC);

// ─── QUERY 3: Participantes Zoom por reunión (trazabilidad completa) ───
// Obtener los meeting IDs del curso
$sql_meetings = "
    SELECT DISTINCT z.zoom_meetingid
    FROM mdl_i3code_acuityZoom z
    WHERE z.courseid = ? AND z.studentid = ?
    AND z.zoom_meetingid IS NOT NULL
";
$stmt_meetings = $pdo->prepare($sql_meetings);
$stmt_meetings->execute([$courseid, $view_userid]);
$meeting_ids = $stmt_meetings->fetchAll(PDO::FETCH_COLUMN);

$participantes_zoom = [];
if (!empty($meeting_ids)) {
    $placeholders = implode(',', array_fill(0, count($meeting_ids), '?'));
    
    // Determinar offset CET/CEST para cada registro
    // CET = UTC+1, CEST = UTC+2 (último domingo de marzo a último domingo de octubre)
    $sql_participantes = "
        SELECT 
            p.zoom_meetingid AS meeting_id,
            p.participant_name AS participante,
            p.participant_email AS email,
            p.join_time AS join_time_utc,
            p.leave_time AS leave_time_utc,
            DATE_FORMAT(CONVERT_TZ(p.join_time, '+00:00', 
                CASE 
                    WHEN p.join_time >= '2026-03-29 01:00:00' AND p.join_time < '2026-10-25 01:00:00' THEN '+02:00'
                    WHEN p.join_time >= '2025-03-30 01:00:00' AND p.join_time < '2025-10-26 01:00:00' THEN '+02:00'
                    ELSE '+01:00'
                END
            ), '%d/%m/%Y') AS fecha_local,
            DATE_FORMAT(CONVERT_TZ(p.join_time, '+00:00', 
                CASE 
                    WHEN p.join_time >= '2026-03-29 01:00:00' AND p.join_time < '2026-10-25 01:00:00' THEN '+02:00'
                    WHEN p.join_time >= '2025-03-30 01:00:00' AND p.join_time < '2025-10-26 01:00:00' THEN '+02:00'
                    ELSE '+01:00'
                END
            ), '%H:%i:%s') AS hora_entrada,
            DATE_FORMAT(CONVERT_TZ(p.leave_time, '+00:00', 
                CASE 
                    WHEN p.leave_time >= '2026-03-29 01:00:00' AND p.leave_time < '2026-10-25 01:00:00' THEN '+02:00'
                    WHEN p.leave_time >= '2025-03-30 01:00:00' AND p.leave_time < '2025-10-26 01:00:00' THEN '+02:00'
                    ELSE '+01:00'
                END
            ), '%H:%i:%s') AS hora_salida,
            p.duration_minutes AS duracion_min,
            z.zoom_username AS tutor_zoom,
            CONCAT(t.firstname, ' ', t.lastname) AS tutor_nombre,
            z.acuity_datetime AS fecha_agendada
        FROM mdl_coding_zoom_participants_unified p
        JOIN mdl_i3code_acuityZoom z ON z.zoom_meetingid = p.zoom_meetingid AND z.studentid = ?
        LEFT JOIN mdl_user t ON t.id = z.teacherid
        WHERE p.zoom_meetingid IN ($placeholders)
        AND p.duration_minutes > 0
        ORDER BY p.join_time ASC, p.duration_minutes DESC
    ";
    
    $params = array_merge([$view_userid], $meeting_ids);
    $stmt_part = $pdo->prepare($sql_participantes);
    $stmt_part->execute($params);
    $all_participants = $stmt_part->fetchAll(PDO::FETCH_ASSOC);
    
    // Agrupar por meeting_id
    foreach ($all_participants as $p) {
        $mid = $p['meeting_id'];
        if (!isset($participantes_zoom[$mid])) {
            $participantes_zoom[$mid] = [];
        }
        $participantes_zoom[$mid][] = $p;
    }
}

// ─── QUERY 4: Info del curso desde own_acuity_course ───
$sql_curso_info = "
    SELECT tipo_clase, classnmbr, isfundae, fecha_inicio
    FROM own_acuity_course
    WHERE courseid = ?
    LIMIT 1
";
$stmt_info = $pdo->prepare($sql_curso_info);
$stmt_info->execute([$courseid]);
$curso_info = $stmt_info->fetch(PDO::FETCH_ASSOC);

// Calcular estadísticas
$total_sesiones = 0;
$total_asistidas = 0;
$total_canceladas = 0;
$total_pendientes = 0;
$total_minutos = 0;

foreach ($detalle_clases as $cl) {
    $total_sesiones++;
    switch ($cl['estado']) {
        case 'ASISTIO': $total_asistidas++; $total_minutos += intval($cl['minutos']); break;
        case 'CANCELADA': $total_canceladas++; break;
        case 'PENDIENTE': case 'NO INICIADA': $total_pendientes++; break;
    }
}

$pct_asistencia = ($total_asistidas + intval($resumen['clases_agendadas'] ?? 0)) > 0
    ? round(($total_asistidas / ($total_asistidas + ($total_sesiones - $total_asistidas - $total_canceladas - $total_pendientes))) * 100, 1)
    : 0;

// Usar el porcentaje de la vista si está disponible (más preciso)
if ($resumen && $resumen['porcentaje_asistencia'] !== null) {
    $pct_asistencia = floatval($resumen['porcentaje_asistencia']);
}

// ─── EXPORTACIÓN EXCEL (HTML con formato) ───
if ($export === 'excel') {
    $filename = 'Tutorias_con_profesor_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $course->fullname) . '_' . fullname($view_user) . '_' . date('Y-m-d') . '.xls';
    $filename = str_replace(' ', '_', $filename);
    
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    
    echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
    echo '<head><meta charset="utf-8">';
    echo '<style>';
    echo 'body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; }';
    echo 'h1 { font-size: 16pt; color: #008ba3; margin-bottom: 4px; }';
    echo 'h2 { font-size: 12pt; color: #424242; margin-bottom: 2px; font-weight: normal; }';
    echo 'h3 { font-size: 11pt; color: #008ba3; margin-top: 16px; border-bottom: 2px solid #008ba3; padding-bottom: 4px; }';
    echo '.meta { font-size: 9pt; color: #64748b; margin-bottom: 12px; }';
    echo '.resumen-table td { padding: 6px 12px; border: 1px solid #e2e8f0; }';
    echo '.resumen-table .label { background: #f1f5f9; font-weight: bold; color: #424242; width: 180px; }';
    echo '.resumen-table .value { color: #008ba3; font-weight: bold; font-size: 12pt; }';
    echo '.sesion-header { background: #008ba3; color: #ffffff; font-weight: bold; padding: 6px 12px; font-size: 10pt; }';
    echo '.sesion-meta td { background: #f8fafc; padding: 4px 12px; font-size: 9pt; color: #64748b; border: 1px solid #e2e8f0; }';
    echo '.data-table { border-collapse: collapse; width: 100%; margin-bottom: 16px; }';
    echo '.data-table th { background: #008ba3; color: #ffffff; padding: 6px 10px; border: 1px solid #006d80; font-size: 9pt; text-align: left; }';
    echo '.data-table td { padding: 5px 10px; border: 1px solid #e2e8f0; font-size: 9pt; }';
    echo '.tutor { color: #008ba3; font-weight: bold; }';
    echo '.estado-asistio { background: #dcfce7; color: #166534; }';
    echo '.estado-cancelada { background: #f3f4f6; color: #6b7280; }';
    echo '.estado-pendiente { background: #fef3c7; color: #92400e; }';
    echo '.footer { font-size: 8pt; color: #9ca3af; margin-top: 20px; border-top: 1px solid #e2e8f0; padding-top: 8px; }';
    echo '</style></head><body>';
    
    // Cabecera del documento
    echo '<h1>📋 Registro de tutorías con profesor</h1>';
    echo '<h2>' . htmlspecialchars($course->fullname) . '</h2>';
    echo '<p class="meta">Documento generado automáticamente por tuSpeaking Platform · ' . date('d/m/Y H:i:s') . '</p>';
    
    // Datos del alumno
    echo '<h3>Datos del alumno</h3>';
    echo '<table class="resumen-table">';
    echo '<tr><td class="label">Alumno/a</td><td>' . fullname($view_user) . '</td></tr>';
    echo '<tr><td class="label">Email</td><td>' . $view_user->email . '</td></tr>';
    echo '<tr><td class="label">Curso</td><td>' . htmlspecialchars($course->fullname) . '</td></tr>';
    if ($curso_info) {
        echo '<tr><td class="label">Tipo de clase</td><td>' . ($curso_info['tipo_clase'] == '1TO1' ? '1 to 1' : 'Grupal') . '</td></tr>';
    }
    if ($resumen) {
        echo '<tr><td class="label">Primera clase</td><td>' . ($resumen['primera_clase'] ? date('d/m/Y', strtotime($resumen['primera_clase'])) : '-') . '</td></tr>';
        echo '<tr><td class="label">Última clase</td><td>' . ($resumen['ultima_clase'] ? date('d/m/Y', strtotime($resumen['ultima_clase'])) : '-') . '</td></tr>';
    }
    echo '</table>';
    
    // Resumen estadístico
    echo '<h3>Resumen de asistencia</h3>';
    echo '<table class="resumen-table">';
    echo '<tr><td class="label">Sesiones realizadas</td><td class="value">' . ($total_sesiones - $total_canceladas - $total_pendientes) . '</td></tr>';
    echo '<tr><td class="label">Asistidas</td><td class="value" style="color:#27ae60">' . $total_asistidas . '</td></tr>';
    echo '<tr><td class="label">Canceladas</td><td class="value" style="color:#9ca3af">' . $total_canceladas . '</td></tr>';
    echo '<tr><td class="label">Pendientes</td><td class="value" style="color:#f39c12">' . $total_pendientes . '</td></tr>';
    echo '<tr><td class="label">Porcentaje asistencia</td><td class="value">' . $pct_asistencia . '%</td></tr>';
    echo '<tr><td class="label">Minutos totales de formación</td><td class="value">' . $total_minutos . ' min (' . round($total_minutos / 60, 1) . ' h)</td></tr>';
    echo '</table>';
    
    // Detalle por sesión
    echo '<h3>Detalle de sesiones (' . count($detalle_clases) . ')</h3>';
    
    foreach ($detalle_clases as $cl) {
        $estado = trim($cl['estado']);
        $estado_class = 'estado-asistio';
        switch ($estado) {
            case 'ASISTIO': $estado_class = 'estado-asistio'; break;
            case 'CANCELADA': $estado_class = 'estado-cancelada'; break;
            default: $estado_class = 'estado-pendiente'; break;
        }
        
        // Buscar meeting_id
        $fecha_sql = null;
        if (preg_match('#(\d{2})/(\d{2})/(\d{4})#', $cl['fecha'], $m)) {
            $fecha_sql = $m[3].'-'.$m[2].'-'.$m[1];
        }
        $meeting_id = null;
        if ($fecha_sql) {
            $sql_mid = "SELECT zoom_meetingid FROM mdl_i3code_acuityZoom WHERE courseid = ? AND studentid = ? AND DATE(acuity_datetime) = ? AND zoom_meetingid IS NOT NULL LIMIT 1";
            $stmt_mid = $pdo->prepare($sql_mid);
            $stmt_mid->execute([$courseid, $view_userid, $fecha_sql]);
            $meeting_id = $stmt_mid->fetchColumn();
        }
        $participants = $meeting_id ? ($participantes_zoom[$meeting_id] ?? []) : [];
        
        // Hash de verificación
        $verify_hash = null;
        if ($meeting_id && !empty($participants)) {
            $hash_data = $meeting_id;
            foreach ($participants as $p) {
                $hash_data .= '|' . $p['join_time_utc'] . '|' . ($p['leave_time_utc'] ?? '');
            }
            $verify_hash = strtoupper(substr(hash('sha256', $hash_data), 0, 16));
        }
        
        // Cabecera de sesión
        echo '<table class="data-table">';
        echo '<tr><td colspan="7" class="sesion-header">';
        echo '📅 ' . $cl['fecha'];
        echo ' · Estado: ' . $estado;
        if ($meeting_id) echo ' · Zoom ID: ' . $meeting_id;
        if ($verify_hash) echo ' · 🔒 Verificación: ' . $verify_hash;
        echo '</td></tr>';
        
        if ($estado === 'ASISTIO' || $estado === 'NO INICIADA') {
            echo '<tr class="sesion-meta">';
            echo '<td colspan="2">👨‍🏫 Tutor: ' . htmlspecialchars($cl['profesor'] ?: 'Sin datos') . '</td>';
            echo '<td>Agendada: ' . ($cl['hora_agendada'] ?: '-') . '</td>';
            echo '<td>Inicio real: ' . ($cl['hora_real'] ?: '-') . '</td>';
            echo '<td>Duración: ' . ($cl['minutos'] ?: '0') . ' min</td>';
            echo '<td>Profesor conectó: ' . ($cl['profesor_conecto'] == 'SI' ? '✅' : '❌') . '</td>';
            if ($meeting_id) echo '<td>URL: https://zoom.us/j/' . $meeting_id . '</td>';
            echo '</tr>';
        }
        
        // Participantes
        if (!empty($participants)) {
            echo '<tr><th>Participante</th><th>Email</th><th>Rol</th><th>Hora entrada</th><th>Hora salida</th><th>Duración (min)</th><th>Verificación</th></tr>';
            foreach ($participants as $p) {
                $is_tutor = !empty($p['email']) && strpos($p['email'], '@live') !== false && strpos($p['email'], 'tuspeaking') !== false;
                echo '<tr>';
                echo '<td>' . htmlspecialchars($p['participante']) . '</td>';
                echo '<td>' . htmlspecialchars($p['email'] ?: '(invitado)') . '</td>';
                echo '<td class="' . ($is_tutor ? 'tutor' : '') . '">' . ($is_tutor ? 'Tutor' : 'Alumno') . '</td>';
                echo '<td>' . $p['hora_entrada'] . '</td>';
                echo '<td>' . $p['hora_salida'] . '</td>';
                echo '<td>' . $p['duracion_min'] . '</td>';
                echo '<td style="font-family:Courier New;font-size:8pt;color:#64748b">' . ($verify_hash ?: '') . '</td>';
                echo '</tr>';
            }
        } else {
            echo '<tr><td colspan="6" style="color:#9ca3af;font-style:italic;">';
            if ($estado === 'CANCELADA') echo 'Sesión cancelada';
            elseif ($estado === 'PENDIENTE') echo 'Sesión pendiente';
            else echo 'Sin datos detallados de participantes';
            echo '</td></tr>';
        }
        echo '</table>';
    }
    
    // Pie
    echo '<div class="footer">';
    echo '<p><strong>tuSpeaking Platform</strong> · Micro Ventures S.L. · CIF B71259352</p>';
    echo '<p>Documento generado: ' . date('d/m/Y H:i:s') . ' · Alumno: ' . fullname($view_user) . ' · Curso: ' . htmlspecialchars($course->fullname) . ' (ID: ' . $courseid . ')</p>';
    echo '<p>Los horarios se muestran en hora local (Europe/Madrid, CET/CEST). Los datos provienen del registro automático de Zoom.</p>';
    echo '<p><strong>Código de verificación:</strong> El código 🔒 de cada sesión es un hash SHA-256 calculado sobre el ID de reunión Zoom y los timestamps UTC de entrada/salida de todos los participantes. Cualquier modificación de los datos invalidaría el código, garantizando la integridad del registro.</p>';
    echo '</div>';
    
    echo '</body></html>';
    exit;
}

echo $OUTPUT->header();
?>
<style>
:root {
    --ts-primary: #008ba3;
    --ts-primary-dark: #006d80;
    --ts-secondary: #00bcd4;
    --ts-light: #e0f7fa;
    --ts-success: #27ae60;
    --ts-warning: #f39c12;
    --ts-danger: #e74c3c;
    --ts-dark: #424242;
    --ts-gray: #64748b;
    --ts-canceled: #9ca3af;
}

.tp-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.tp-header {
    background: linear-gradient(135deg, var(--ts-primary), var(--ts-secondary));
    color: #fff;
    padding: 24px 28px;
    border-radius: 16px 16px 0 0;
    margin-bottom: 0;
}

.tp-header h2 {
    margin: 0 0 4px;
    font-size: 1.3em;
    font-weight: 700;
    color: #fff;
}

.tp-header .tp-subtitle {
    color: rgba(255,255,255,.9);
    font-size: .9em;
    margin: 0;
}

.tp-header .tp-badge-fundae {
    display: inline-block;
    background: rgba(255,255,255,.2);
    color: #fff;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: .75em;
    font-weight: 600;
    margin-top: 8px;
    border: 1px solid rgba(255,255,255,.3);
}

.tp-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    padding: 20px 28px;
    gap: 12px;
    background: #f8fafc;
    border-left: 1px solid #e2e8f0;
    border-right: 1px solid #e2e8f0;
}

.tp-stat {
    text-align: center;
    padding: 14px 10px;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 1px 4px rgba(0,0,0,.06);
}

.tp-stat strong {
    display: block;
    font-size: 1.6em;
    font-weight: 700;
    margin-bottom: 4px;
}

.tp-stat small {
    color: var(--ts-gray);
    font-size: .8em;
}

.tp-stat.green strong { color: var(--ts-success); }
.tp-stat.red strong { color: var(--ts-danger); }
.tp-stat.orange strong { color: var(--ts-warning); }
.tp-stat.blue strong { color: var(--ts-primary); }
.tp-stat.gray strong { color: var(--ts-gray); }

.tp-alumno-info {
    padding: 16px 28px;
    background: #fff;
    border-left: 1px solid #e2e8f0;
    border-right: 1px solid #e2e8f0;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    gap: 24px;
    flex-wrap: wrap;
    font-size: .9em;
}

.tp-alumno-info .tp-field {
    display: flex;
    flex-direction: column;
}

.tp-alumno-info .tp-field label {
    color: var(--ts-gray);
    font-size: .75em;
    text-transform: uppercase;
    font-weight: 600;
    margin-bottom: 2px;
}

.tp-alumno-info .tp-field span {
    color: var(--ts-dark);
    font-weight: 500;
}

.tp-section-title {
    margin: 28px 0 16px;
    color: var(--ts-dark);
    border-bottom: 2px solid #e2e8f0;
    padding-bottom: 12px;
    font-size: 1.1em;
    font-weight: 600;
}

/* ─── Tabla de sesiones ─── */
.tp-sesion {
    background: #fff;
    border-radius: 12px;
    margin-bottom: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
    overflow: hidden;
    border: 1px solid #e2e8f0;
}

.tp-sesion-header {
    padding: 14px 20px;
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
}

.tp-sesion-header .tp-fecha {
    font-weight: 600;
    color: var(--ts-dark);
    font-size: .95em;
}

.tp-sesion-header .tp-meeting-id {
    color: var(--ts-gray);
    font-size: .8em;
    font-family: 'Courier New', monospace;
}

.tp-sesion-header .tp-estado {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: .75em;
    font-weight: 600;
    color: #fff;
}

.tp-estado-asistio { background: var(--ts-success); }
.tp-estado-cancelada { background: var(--ts-canceled); }
.tp-estado-pendiente { background: var(--ts-warning); }
.tp-estado-noiniciada { background: var(--ts-gray); }

.tp-sesion-meta {
    padding: 10px 20px;
    background: #fafbfc;
    border-bottom: 1px solid #f1f5f9;
    display: flex;
    gap: 24px;
    flex-wrap: wrap;
    font-size: .85em;
    color: var(--ts-gray);
}

.tp-sesion-meta strong {
    color: var(--ts-dark);
}

/* Tabla de participantes dentro de cada sesión */
.tp-participantes-table {
    width: 100%;
    border-collapse: collapse;
    font-size: .85em;
}

.tp-participantes-table thead {
    background: #f1f5f9;
}

.tp-participantes-table th {
    padding: 10px 16px;
    text-align: left;
    color: var(--ts-gray);
    font-weight: 600;
    font-size: .8em;
    text-transform: uppercase;
    letter-spacing: .5px;
    border-bottom: 1px solid #e2e8f0;
}

.tp-participantes-table td {
    padding: 10px 16px;
    border-bottom: 1px solid #f1f5f9;
    color: var(--ts-dark);
}

.tp-participantes-table tr:last-child td {
    border-bottom: none;
}

.tp-participantes-table .tp-rol-tutor {
    color: var(--ts-primary);
    font-weight: 600;
}

.tp-participantes-table .tp-rol-alumno {
    color: var(--ts-dark);
}

.tp-no-zoom {
    padding: 16px 20px;
    color: var(--ts-gray);
    font-style: italic;
    font-size: .85em;
}

.tp-back-link {
    color: var(--ts-primary);
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 16px;
    font-weight: 500;
}

.tp-back-link:hover {
    text-decoration: underline;
    color: var(--ts-primary-dark);
}

.tp-footer-note {
    margin-top: 24px;
    padding: 16px 20px;
    background: #f8fafc;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
    font-size: .8em;
    color: var(--ts-gray);
}

.tp-footer-note strong {
    color: var(--ts-dark);
}

.tp-export-bar {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-bottom: 16px;
}

.tp-btn-export {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: #fff;
    color: var(--ts-primary);
    border: 2px solid var(--ts-primary);
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    font-size: .9em;
    transition: all .2s;
    cursor: pointer;
}

.tp-btn-export:hover {
    background: var(--ts-primary);
    color: #fff;
    text-decoration: none;
    box-shadow: 0 4px 12px rgba(0,139,163,.3);
}

@media (max-width: 768px) {
    .tp-stats { grid-template-columns: repeat(3, 1fr); }
    .tp-sesion-header { flex-direction: column; align-items: flex-start; }
    .tp-sesion-meta { flex-direction: column; gap: 8px; }
    .tp-participantes-table { font-size: .8em; }
    .tp-participantes-table th, .tp-participantes-table td { padding: 8px 10px; }
}
</style>

<div class="tp-container">

    <a href="<?php echo $CFG->wwwroot; ?>/course/view.php?id=<?php echo $courseid; ?>" class="tp-back-link">← Volver al curso</a>

    <div class="tp-export-bar">
        <a href="?courseid=<?php echo $courseid; ?>&userid=<?php echo $view_userid; ?>&export=excel" class="tp-btn-export">
            📥 Descargar Excel
        </a>
    </div>

    <!-- ─── CABECERA ─── -->
    <div class="tp-header">
        <h2>📋 Tutorías con profesor</h2>
        <p class="tp-subtitle"><?php echo htmlspecialchars($course->fullname); ?></p>
        <?php if ($curso_info && $curso_info['isfundae']): ?>
        <span class="tp-badge-fundae">📑 Curso FUNDAE · Tipo: <?php echo $curso_info['tipo_clase'] == '1TO1' ? '1 to 1' : 'Grupal'; ?></span>
        <?php endif; ?>
    </div>

    <!-- ─── ESTADÍSTICAS ─── -->
    <div class="tp-stats">
        <div class="tp-stat blue">
            <strong><?php echo $total_sesiones - $total_canceladas - $total_pendientes; ?></strong>
            <small>Sesiones realizadas</small>
        </div>
        <div class="tp-stat green">
            <strong><?php echo $total_asistidas; ?></strong>
            <small>Asistidas</small>
        </div>
        <div class="tp-stat <?php echo $pct_asistencia >= 75 ? 'green' : ($pct_asistencia >= 50 ? 'orange' : 'red'); ?>">
            <strong><?php echo $pct_asistencia; ?>%</strong>
            <small>Asistencia</small>
        </div>
        <div class="tp-stat blue">
            <strong><?php echo $total_minutos; ?></strong>
            <small>Minutos totales</small>
        </div>
        <div class="tp-stat gray">
            <strong><?php echo $total_canceladas; ?></strong>
            <small>Canceladas</small>
        </div>
        <div class="tp-stat orange">
            <strong><?php echo $total_pendientes; ?></strong>
            <small>Pendientes</small>
        </div>
    </div>

    <!-- ─── DATOS DEL ALUMNO ─── -->
    <div class="tp-alumno-info">
        <div class="tp-field">
            <label>Alumno/a</label>
            <span><?php echo fullname($view_user); ?></span>
        </div>
        <div class="tp-field">
            <label>Email</label>
            <span><?php echo $view_user->email; ?></span>
        </div>
        <div class="tp-field">
            <label>Curso</label>
            <span><?php echo htmlspecialchars($course->fullname); ?></span>
        </div>
        <?php if ($resumen): ?>
        <div class="tp-field">
            <label>Primera clase</label>
            <span><?php echo $resumen['primera_clase'] ? date('d/m/Y', strtotime($resumen['primera_clase'])) : '-'; ?></span>
        </div>
        <div class="tp-field">
            <label>Última clase</label>
            <span><?php echo $resumen['ultima_clase'] ? date('d/m/Y', strtotime($resumen['ultima_clase'])) : '-'; ?></span>
        </div>
        <?php endif; ?>
    </div>

    <!-- ─── DETALLE POR SESIÓN ─── -->
    <h3 class="tp-section-title">📅 Registro de sesiones (<?php echo count($detalle_clases); ?>)</h3>

    <?php foreach ($detalle_clases as $cl):
        $estado = trim($cl['estado']);
        $estado_class = 'tp-estado-asistio';
        $estado_label = $estado;
        
        switch ($estado) {
            case 'ASISTIO': $estado_class = 'tp-estado-asistio'; $estado_label = 'Asistió'; break;
            case 'CANCELADA': $estado_class = 'tp-estado-cancelada'; $estado_label = 'Cancelada'; break;
            case 'PENDIENTE': $estado_class = 'tp-estado-pendiente'; $estado_label = 'Pendiente'; break;
            case 'NO INICIADA': $estado_class = 'tp-estado-noiniciada'; $estado_label = 'No iniciada'; break;
        }
        
        // Buscar meeting_id para esta fecha desde mdl_i3code_acuityZoom
        $fecha_sql = null;
        if (preg_match('#(\d{2})/(\d{2})/(\d{4})#', $cl['fecha'], $m)) {
            $fecha_sql = $m[3].'-'.$m[2].'-'.$m[1];
        }
        
        // Buscar el meeting_id correspondiente
        $meeting_id = null;
        if ($fecha_sql) {
            $sql_mid = "SELECT zoom_meetingid FROM mdl_i3code_acuityZoom 
                        WHERE courseid = ? AND studentid = ? 
                        AND DATE(acuity_datetime) = ?
                        AND zoom_meetingid IS NOT NULL
                        LIMIT 1";
            $stmt_mid = $pdo->prepare($sql_mid);
            $stmt_mid->execute([$courseid, $view_userid, $fecha_sql]);
            $meeting_id = $stmt_mid->fetchColumn();
        }
        
        $participants = $meeting_id ? ($participantes_zoom[$meeting_id] ?? []) : [];
        
        // Generar hash de verificación SHA-256 para trazabilidad FUNDAE
        $verify_hash = null;
        $zoom_url = null;
        if ($meeting_id && !empty($participants)) {
            // Datos inmutables para el hash: meeting_id + todos los join/leave times
            $hash_data = $meeting_id;
            foreach ($participants as $p) {
                $hash_data .= '|' . $p['join_time_utc'] . '|' . ($p['leave_time_utc'] ?? '');
            }
            $verify_hash = strtoupper(substr(hash('sha256', $hash_data), 0, 16));
            $zoom_url = 'https://zoom.us/j/' . $meeting_id;
        }
    ?>
    <div class="tp-sesion">
        <div class="tp-sesion-header">
            <span class="tp-fecha">📅 <?php echo $cl['fecha']; ?></span>
            <?php if ($meeting_id): ?>
            <span class="tp-meeting-id">Zoom ID: <a href="<?php echo $zoom_url; ?>" target="_blank" style="color:inherit;text-decoration:underline;"><?php echo $meeting_id; ?></a></span>
            <?php endif; ?>
            <?php if ($verify_hash): ?>
            <span class="tp-meeting-id" title="Código de verificación SHA-256 calculado sobre los datos de la sesión Zoom">🔒 <?php echo $verify_hash; ?></span>
            <?php endif; ?>
            <span class="tp-estado <?php echo $estado_class; ?>"><?php echo $estado_label; ?></span>
        </div>
        
        <?php if ($estado === 'ASISTIO' || $estado === 'NO INICIADA'): ?>
        <div class="tp-sesion-meta">
            <span>👨‍🏫 Tutor: <strong><?php echo htmlspecialchars($cl['profesor'] ?: 'Sin datos'); ?></strong></span>
            <span>🕐 Hora agendada: <strong><?php echo $cl['hora_agendada'] ?: '-'; ?></strong></span>
            <?php if ($cl['hora_real']): ?>
            <span>▶️ Hora real inicio: <strong><?php echo $cl['hora_real']; ?></strong></span>
            <?php endif; ?>
            <span>⏱ Duración: <strong><?php echo $cl['minutos'] ?: '0'; ?> min</strong></span>
            <span>📡 Profesor conectó: <strong><?php echo $cl['profesor_conecto'] == 'SI' ? '✅ Sí' : '❌ No'; ?></strong></span>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($participants)): ?>
        <table class="tp-participantes-table">
            <thead>
                <tr>
                    <th>Participante</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Hora entrada</th>
                    <th>Hora salida</th>
                    <th>Duración (min)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($participants as $p): 
                    $is_tutor = !empty($p['email']) && strpos($p['email'], '@live') !== false && strpos($p['email'], 'tuspeaking') !== false;
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($p['participante']); ?></td>
                    <td><?php echo htmlspecialchars($p['email'] ?: '(invitado)'); ?></td>
                    <td class="<?php echo $is_tutor ? 'tp-rol-tutor' : 'tp-rol-alumno'; ?>">
                        <?php echo $is_tutor ? '👨‍🏫 Tutor' : '👤 Alumno'; ?>
                    </td>
                    <td><?php echo $p['hora_entrada']; ?></td>
                    <td><?php echo $p['hora_salida']; ?></td>
                    <td><?php echo $p['duracion_min']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php elseif ($estado === 'ASISTIO'): ?>
        <div class="tp-no-zoom">
            ℹ️ Sesión registrada como asistida. Datos detallados de participantes Zoom no disponibles para esta sesión.
        </div>
        <?php elseif ($estado === 'CANCELADA'): ?>
        <div class="tp-no-zoom">
            🚫 Sesión cancelada — sin registro de participantes.
        </div>
        <?php elseif ($estado === 'PENDIENTE'): ?>
        <div class="tp-no-zoom">
            🕐 Sesión pendiente de realización.
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>

    <?php if (empty($detalle_clases)): ?>
    <div class="tp-sesion">
        <div class="tp-no-zoom" style="padding: 30px; text-align: center;">
            No se encontraron sesiones de tutoría registradas para este curso.
        </div>
    </div>
    <?php endif; ?>

    <!-- ─── PIE ─── -->
    <div class="tp-footer-note">
        <strong>Nota sobre los datos:</strong> Los horarios se muestran en hora local (Europe/Madrid, CET/CEST). 
        Los datos de participantes y duración provienen del registro automático de Zoom. 
        La hora de entrada y salida corresponden al momento exacto en que cada participante 
        se conectó y desconectó de la videoconferencia.
        <br><br>
        <strong>Generado:</strong> <?php echo date('d/m/Y H:i:s'); ?> · 
        <strong>Alumno:</strong> <?php echo fullname($view_user); ?> · 
        <strong>Curso:</strong> <?php echo htmlspecialchars($course->fullname); ?> (ID: <?php echo $courseid; ?>)
    </div>

</div>

<?php
echo $OUTPUT->footer();
?>
