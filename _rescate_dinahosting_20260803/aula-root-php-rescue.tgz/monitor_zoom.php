<?php
$pdo = new PDO("mysql:host=localhost;dbname=aulatuspeaking35;charset=utf8mb4","moodle35","TuspeakingFix2025!");

$i3 = $pdo->query("SELECT MAX(zoom_jointime) as u, COUNT(*) as c FROM mdl_i3code_acuityZoom_participants")->fetch();
$i3_horas = $i3['u'] ? round((time()-strtotime($i3['u']))/3600,1) : 999;
$i3_ok = $i3_horas < 48;
$i3_meet = $pdo->query("SELECT COUNT(*) as c FROM mdl_i3code_acuityZoom")->fetch();

$cesce = $pdo->query("SELECT MAX(join_time) as u, COUNT(*) as c FROM mdl_coding_zoom_participants")->fetch();
$cesce_horas = $cesce['u'] ? round((time()-strtotime($cesce['u']))/3600,1) : 999;

$estado = $i3_ok ? 'ok' : 'error';
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Monitor Zoom</title>
<style>
body{font-family:system-ui;background:#f5f7fa;padding:20px;max-width:900px;margin:0 auto}
.card{background:#fff;border-radius:12px;padding:20px;margin:15px 0;box-shadow:0 2px 8px rgba(0,0,0,.1)}
h1{color:#008ba3}.ok{color:#27ae60;font-weight:bold}.error{color:#e74c3c;font-weight:bold}.warning{color:#f39c12;font-weight:bold}
.badge{display:inline-block;padding:8px 16px;border-radius:20px;color:#fff;font-weight:bold}
.badge.ok{background:#27ae60}.badge.error{background:#e74c3c}
.metric{display:flex;justify-content:space-between;padding:12px;background:#f8f9fa;border-radius:8px;margin:10px 0}
a.btn{display:inline-block;background:#008ba3;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;margin:5px}
</style></head>
<body>
<h1>📊 Monitor Ingesta Zoom</h1>
<div class="card"><div style="display:flex;justify-content:space-between;align-items:center">
<h2 style="margin:0">Estado</h2><span class="badge <?=$estado?>"><?=$estado=='ok'?'✓ OK':'⚠ REVISAR'?></span>
</div></div>
<div class="card"><h3>✅ i3code (Automático)</h3>
<div class="metric"><span>Último</span><span class="<?=$i3_ok?'ok':'error'?>"><?=$i3['u']?> (<?=$i3_horas?>h)</span></div>
<div class="metric"><span>Reuniones</span><span><?=number_format($i3_meet['c'])?></span></div>
<div class="metric"><span>Participantes</span><span><?=number_format($i3['c'])?></span></div>
</div>
<div class="card"><h3>📋 CESCE (Manual)</h3>
<div class="metric"><span>Último</span><span class="<?=$cesce_horas<168?'ok':'warning'?>"><?=$cesce['u']?> (<?=$cesce_horas?>h)</span></div>
<div class="metric"><span>Participantes</span><span><?=number_format($cesce['c'])?></span></div>
</div>
<div class="card"><h3>🔧 Acciones</h3>
<a class="btn" href="/app/moodle/coding_zoom_import.php">📥 Importar CSV</a>
<a class="btn" href="/app/moodle/reporte_cesce.php">📊 Reporte CESCE</a>
</div>
<p style="color:#888;text-align:center"><?=date('d/m/Y H:i:s')?></p>
</body></html>
