<?php
/******************************************************
 * tuSpeaking — Acta de tutoría / Tutoring report
 * Ruta esperada: /app/moodle/formFeedback.php
 * Requiere: askddbb.php, mailsender.php, fpdf/fpdfHTML.php
 ******************************************************/

// ====== CARGA DE DEPENDENCIAS (mantén tus rutas) ======
require_once __DIR__ . '/askddbb.php';        // askmysql(), setMysql()
require_once __DIR__ . '/mailsender.php';     // sendEmail()
require_once __DIR__ . '/fpdf/fpdfHTML.php';  // PDF_HTML

// === Opcional: integrar control de acceso de Moodle si está disponible ===
$MOODLE_OK = false;
$COURSE_ID_FROM_ACUITY = 0;

// intenta localizar config.php (ajusta rutas si tu form está en /app/moodle/)
$mo_paths = [
    __DIR__ . '/config.php',                 // mismo dir
    dirname(__DIR__, 1) . '/config.php',     // /app/config.php
    dirname(__DIR__, 2) . '/config.php',     // /config.php (raíz moodle)
];
foreach ($mo_paths as $p) {
    if (is_readable($p)) {
        require_once $p;
        $MOODLE_OK = true;
        break;
    }
}

if ($MOODLE_OK) {
    // Recupera acuityid de GET (no uses required_param si no estás 100% en Moodle)
    $acuityid_qs = isset($_GET['acuityid']) ? (int)$_GET['acuityid'] : 0;

    // Intenta inferir courseid desde tu tabla own_acuity para construir el contexto
    if ($acuityid_qs > 0) {
        try {
            $row = askmysql("SELECT courseid FROM own_acuity WHERE acuityid = {$acuityid_qs}");
            if (!empty($row[0]['courseid'])) {
                $COURSE_ID_FROM_ACUITY = (int)$row[0]['courseid'];
            }
        } catch (\Throwable $e) { /* sigue sin romper */ }
    }

    // Comprueba usuario y roles (modo compatible con 3.5)
    if (isset($USER) && !empty($USER->id)) {
        // is_siteadmin() existe en Moodle moderno
        $isadmin = function_exists('is_siteadmin') ? is_siteadmin($USER->id) : false;

        $allowed = $isadmin;

        // Roles por contexto de curso si lo tenemos
        if (!$allowed && $COURSE_ID_FROM_ACUITY > 0) {
            // get_context_instance está deprecated pero existe en 3.5
            if (function_exists('get_context_instance')) {
                $ctx = get_context_instance(CONTEXT_COURSE, $COURSE_ID_FROM_ACUITY, true);
            } elseif (class_exists('\\context_course')) {
                $ctx = \context_course::instance($COURSE_ID_FROM_ACUITY, MUST_EXIST);
            } else {
                $ctx = null;
            }

            if ($ctx) {
                $roles = get_user_roles($ctx, $USER->id, true);
                if (!empty($roles)) {
                    // Cualquiera de estos roles puede usar el formulario
                    foreach ($roles as $r) {
                        $sn = isset($r->shortname) ? $r->shortname : '';
                        if ($sn === 'manager' || $sn === 'teacher' || $sn === 'editingteacher') {
                            $allowed = true;
                            break;
                        }
                    }
                }
            }
        }

        // Si no hay courseid (p.ej. acta independiente), da acceso a admin/profesor por rol del sistema si se desea:
        if (!$allowed && function_exists('user_has_role_assignment')) {
            // ejemplo: permitir managers globales
            // $allowed = user_has_role_assignment($USER->id, 1); // roleid=1 => manager (ajusta si quieres)
        }

        if (!$allowed) {
            // Redirección segura a la home del app
            header("Location: https://{$SITE_HOST}/app/moodle/");
            exit;
        }
    } else {
        // No hay $USER con sesión: envía a login de Moodle o a tu app
        header("Location: https://{$SITE_HOST}/login/index.php");
        exit;
    }
}
// === /FIN patch seguridad Moodle ===

// ====== CONFIG GENERAL ======
$SITE_HOST = $_SERVER['HTTP_HOST'] ?? 'aula.tuspeaking.com';
$PDF_DIR   = '/home/aulatuspeaking/www/app/moodle/pdf/';   // Debe existir o se crea
$FALLBACK  = '/app/moodle/calendar/view.php?view=upcoming';

// Idioma por query/post (default ES)
$lang = 'en';
if ((isset($_GET['lang']) && $_GET['lang'] === 'en') || (isset($_POST['lang']) && $_POST['lang'] === 'en')) {
    $lang = 'en';
}

// Textos
$T = [
  'es' => [
    'pageTitle' => 'Acta de tutoría',
    'back' => 'Atrás',
    'myclasses' => 'Mis próximas clases',
    'course' => 'Volver al curso',
    'event' => 'Evento',
    'support' => 'Soporte',
    'formTitle' => 'Acta de tutoría',
    'student' => 'Alumno',
    'teacher' => 'Profesor',
    'topic' => 'Tema de conversación',
    'questions' => 'Preguntas relacionadas con el tema',
    'resource' => 'Recursos utilizados',
    'corrections' => 'Correcciones y vocabulario',
    'good' => 'Qué has hecho bien',
    'bad' => 'Aspectos a mejorar',
    'next' => 'Tema para la próxima clase',
    'comments' => 'Comentarios del profesor',
    'submit' => 'Enviar acta',
    'success' => 'Acta generada correctamente.',
    'viewReport' => 'Ver Acta / View report (PDF)',
    'emailBody' => 'Adjuntamos tu acta de tutoría (PDF).',
    'emailSubject' => 'Acta de tutoría',
  ],
  'en' => [
    'pageTitle' => 'Tutoring report',
    'back' => 'Back',
    'myclasses' => 'My upcoming classes',
    'course' => 'Back to course',
    'event' => 'Event',
    'support' => 'Support',
    'formTitle' => 'Tutoring report',
    'student' => 'Student',
    'teacher' => 'Teacher',
    'topic' => 'Conversation topic',
    'questions' => 'Topic related questions',
    'resource' => 'Resources used',
    'corrections' => 'Vocabulary and corrections',
    'good' => 'What you did well',
    'bad' => 'Where you need to improve',
    'next' => 'For next class',
    'comments' => 'Teacher comments',
    'submit' => 'Submit report',
    'success' => 'Report generated successfully.',
    'viewReport' => 'View report (PDF) / Ver Acta',
    'emailBody' => 'Please find attached your tutoring report (PDF).',
    'emailSubject' => 'Tutoring report',
  ]
][$lang];

// Helpers
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Validar `return` para evitar open-redirects
function safeReturnUrl($raw, $host, $fallback){
    if (!$raw) return $fallback;
    $pu = @parse_url($raw);
    if (!$pu) return $fallback;
    if (isset($pu['host']) && $pu['host'] !== $host) return $fallback;
    $path = $pu['path'] ?? '';
    if (strpos($path, '/app/moodle/') === 0 || strpos($path, '/moodle/') === 0 || strpos($path, '/app/') === 0) {
        return $raw;
    }
    return $fallback;
}

$returnParam = $_GET['return'] ?? '';
$returnUrl   = safeReturnUrl($returnParam, $SITE_HOST, $FALLBACK);

// IDs (si vienen por GET para pre-rellenar hidden)
$acuityID_get  = isset($_GET['acuityid'])  ? (int)$_GET['acuityid']  : 0;
$studentID_get = isset($_GET['studentID']) ? (int)$_GET['studentID'] : 0;
$teacherID_get = isset($_GET['teacherID']) ? (int)$_GET['teacherID'] : 0;

$courseid = isset($_GET['courseid']) ? (int)$_GET['courseid'] : 0;
$eventid  = isset($_GET['eventid'])  ? (int)$_GET['eventid']  : 0;

// Normalizador de textos (tu FPDF usa ISO; seguimos tu patrón original)
$norm = function($s){
    $s = (string)$s;
    $s = str_replace(["\r\n", "\r"], "\n", $s);
    $s = str_replace("\n", "<br>", $s);
    return utf8_decode($s);
};

// === POST: procesar y salir con pantalla de éxito ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitizado mínimo de IDs
    $studentID = isset($_POST['studentID']) ? (int)$_POST['studentID'] : 0;
    $teacherID = isset($_POST['teacherID']) ? (int)$_POST['teacherID'] : 0;
    $acuityID  = isset($_POST['acuityID'])  ? (int)$_POST['acuityID']  : 0;

    // Cargar datos de alumno y profesor
    $student = $studentID ? askmysql("SELECT firstname, lastname, email FROM mdl_user WHERE id = {$studentID}") : [];
    $teacher = $teacherID ? askmysql("SELECT firstname, lastname, email FROM mdl_user WHERE id = {$teacherID}") : [];

    // Campos del acta
    $topic       = $norm($_POST['topic']       ?? '');
    $questions   = $norm($_POST['questions']   ?? '');
    $resource    = $norm($_POST['resource']    ?? '');
    $corrections = $norm($_POST['corrections'] ?? '');
    $good        = $norm($_POST['good']        ?? '');
    $bad         = $norm($_POST['bad']         ?? '');
    $next        = $norm($_POST['next']        ?? '');
    $comments    = $norm($_POST['comments']    ?? '');

    if (trim($comments) === '') {
        $comments = "Thank you ".utf8_decode(($student[0]['firstname'] ?? 'student')).". It was a pleasure to speak with you.";
    }

    // Asegurar carpeta PDF
    if (!is_dir($PDF_DIR)) { @mkdir($PDF_DIR, 0775, true); }

    // Fechas y nombres de archivo
    $nowDT    = new DateTime();
    $fileDate = $nowDT->format('Y-m-d');
    $safeName = preg_replace('/[^A-Za-z0-9\-_.]/','-', ($student[0]['firstname'] ?? 'Student')."-".($student[0]['lastname'] ?? 'Name'));
    $tempName = "Acta-de-tutoria-{$safeName}-{$fileDate}.pdf";

    // Fecha larga (ES), con fallback EN si el locale no está
    $ts = $nowDT->getTimestamp();
    @setlocale(LC_ALL, "es_ES.UTF-8", "es_ES", "es");
    $fechaLarga = @strftime('%A, %e %B %Y', $ts);
    if (!$fechaLarga || $fechaLarga === '') { $fechaLarga = $nowDT->format('l, j F Y'); }

    // Contenido del PDF (bilingüe en secciones)
    $pdfHTML =
        "<p><b>Conversation topic / ".utf8_decode('Tema de conversación')."</b><br>{$topic}</p>".
        "<p><b>Topic related questions / Preguntas relacionadas con el tema</b><br>{$questions}</p>".
        "<p><b>Resources used / Recursos utilizados</b><br>{$resource}</p>".
        "<p><b>Vocabulary and corrections / Correcciones y vocabulario</b><br>{$corrections}</p>".
        "<p><b>What you did well / ".utf8_decode('Qué has hecho bien')."</b><br>{$good}</p>".
        "<p><b>Where you need to improve / ".utf8_decode('Aspectos a mejorar')."</b><br>{$bad}</p>".
        "<p><b>For next class / ". utf8_decode('Tema para la próxima clase')."</b><br>{$next}</p>".
        "<p><b>Teacher comments / Comentarios del profesor</b><br>{$comments}</p>";

    // Crear PDF
    $pdf = new PDF_HTML();
    $pdf->setTopMargin(4);
    $pdfTitle = ($lang === 'en') ? 'Tutoring report / Acta de tutoría' : 'Acta de tutoría / Tutoring report';
    $pdf->SetTitle($pdfTitle);
    $pdf->setName( utf8_decode(($student[0]['firstname'] ?? '')." ".($student[0]['lastname'] ?? '')) );
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Arial','',20);
    $pdf->Cell(0, 10, utf8_decode($pdfTitle), 0, 0, 'C');
    $pdf->Ln(5);
    $pdf->SetFont('Arial','',12);
    $pdf->WriteHTML($pdfHTML);

    // Guardar temporal y renombrar a {acuityID}.pdf (compatibilidad)
    $pdf->Output($PDF_DIR . $tempName, 'F');
    $finalName = ($acuityID > 0 ? $acuityID : ('acta-'.$fileDate.'-'.uniqid())). ".pdf";
    @rename($PDF_DIR.$tempName, $PDF_DIR.$finalName);

    // Enviar email al alumno
    $subject = ($lang === 'en'
        ? $T['emailSubject']." – ".(($student[0]['firstname'] ?? '')." ".($student[0]['lastname'] ?? ''))." – ".$fileDate
        : $T['emailSubject']." – ".(($student[0]['firstname'] ?? '')." ".($student[0]['lastname'] ?? ''))." – ".$fileDate
    );
    $body = ($lang === 'en')
        ? "Hello ".($student[0]['firstname'] ?? 'student').",\n\n".$T['emailBody']
        : "Hola ".($student[0]['firstname'] ?? 'alumno').",\n\n".$T['emailBody'];

    // Ajusta remitente si quieres (antes era hansel@..., lo dejamos genérico soporte@)
    @sendEmail(($student[0]['email'] ?? ''), $subject, $body, 'soporte@tuspeaking.com', "/app/moodle/pdf/".$finalName);

    // Añadir botón PDF en descripciones de eventos (evitar duplicados)
    if ($acuityID > 0) {
        $events = askmysql("SELECT studenteventid, teachereventid, heventid, ceventid, geventid FROM own_acuity WHERE acuityid = {$acuityID}");
        $ids = [];
        if (!empty($events[0])) {
            foreach (['studenteventid','teachereventid','heventid','ceventid','geventid'] as $k) {
                if (!empty($events[0][$k])) $ids[] = (int)$events[0][$k];
            }
        }
        $viewPDF = "<br><div style='margin-top:10px;'><a href='/app/moodle/pdf/{$finalName}' target='_blank' class='acuity-embed-button' style='background:#00bcd4;color:#fff;padding:10px 14px;border-radius:6px;text-decoration:none'>"
                 . utf8_decode($T['viewReport'])
                 . "</a></div>";

        foreach ($ids as $evId) {
            $row = askmysql("SELECT description FROM mdl_event WHERE id = {$evId}");
            if (!empty($row[0]['description'])) {
                $desc = $row[0]['description'];
                if (strpos($desc, "/app/moodle/pdf/{$finalName}") === false) { // evitar duplicados
                    $descNew = addslashes($desc . $viewPDF);
                    setMysql("UPDATE mdl_event SET description = \"{$descNew}\" WHERE id = {$evId};");
                }
            }
        }
    }

    // ====== SALIDA DE ÉXITO (HTML mínimo) ======
    $docTitle = $T['pageTitle'] . ' · tuSpeaking';
    ?>
    <!doctype html>
    <html lang="<?php echo $lang === 'en' ? 'en' : 'es'; ?>">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title><?php echo h($docTitle); ?></title>
      <style>
        .ts-mininav{display:flex;gap:.75rem;align-items:center;padding:.6rem 1rem;border-bottom:1px solid #eee;background:#fff;position:sticky;top:0;z-index:10}
        .ts-mininav a{font:500 14px/1.2 system-ui,-apple-system,Segoe UI,Roboto,Arial;color:#006b80;text-decoration:none;padding:.35rem .6rem;border-radius:.5rem;border:1px solid #cfe9ee}
        .ts-mininav a:hover{background:#f2fbfd}
        .ts-spacer{flex:1}
        .ts-btn{display:inline-flex;align-items:center;gap:.4rem;padding:.5rem .8rem;border-radius:.6rem;border:1px solid #d0d7de;background:#fff;color:#222;text-decoration:none;cursor:pointer}
        .ts-btn.primary{background:#00bcd4;border-color:#00bcd4;color:#fff}
        .wrap{max-width:840px;margin:1rem auto;padding:0 1rem}
        h1{font:600 22px/1.2 system-ui,-apple-system,Segoe UI,Roboto,Arial;margin:.75rem 0 1rem}
        .ok{background:#f5fffa;border:1px solid #cceedd;border-radius:10px;padding:1rem;margin-bottom:1rem}
        .actions{display:flex;gap:.75rem;margin-top:1rem}
      </style>
    </head>
    <body>
      <nav class="ts-mininav">
        <a href="/app/moodle/calendar/view.php?view=upcoming"><?php echo h($T['myclasses']); ?></a>
        <?php if ($courseid): ?><a href="/moodle/course/view.php?id=<?php echo (int)$courseid; ?>"><?php echo h($T['course']); ?></a><?php endif; ?>
        <?php if ($eventid):  ?><a href="/moodle/calendar/view.php?view=day&eventid=<?php echo (int)$eventid; ?>"><?php echo h($T['event']); ?></a><?php endif; ?>
        <div class="ts-spacer"></div>
        <a class="ts-btn" href="<?php echo h($returnUrl); ?>">← <?php echo h($T['back']); ?></a>
        <a class="ts-btn" href="mailto:soporte@tuspeaking.com"><?php echo h($T['support']); ?></a>
      </nav>
      <div class="wrap">
        <h1><?php echo h($T['pageTitle']); ?></h1>
        <div class="ok">
          <p><?php echo h($T['success']); ?></p>
          <p><a class="ts-btn primary" target="_blank" href="<?php echo '/app/moodle/pdf/'.h($finalName); ?>">📄 <?php echo h($T['viewReport']); ?></a></p>
        </div>
        <div class="actions">
          <a class="ts-btn" href="<?php echo h($returnUrl); ?>">← <?php echo h($T['back']); ?></a>
          <a class="ts-btn" href="?<?php echo http_build_query(['acuityid'=>$acuityID,'lang'=>$lang,'return'=>$returnUrl,'courseid'=>$courseid,'eventid'=>$eventid]); ?>">+ <?php echo h($T['submit']); ?></a>
        </div>
      </div>
    </body>
    </html>
    <?php
    exit;
}

// === GET: PINTAR FORMULARIO (manteniendo nombres de campo) ===
$docTitle = $T['pageTitle'] . ' · tuSpeaking';
?>
<!doctype html>
<html lang="<?php echo $lang === 'en' ? 'en' : 'es'; ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo h($docTitle); ?></title>
  <style>
    .ts-mininav{display:flex;gap:.75rem;align-items:center;padding:.6rem 1rem;border-bottom:1px solid #eee;background:#fff;position:sticky;top:0;z-index:10}
    .ts-mininav a{font:500 14px/1.2 system-ui,-apple-system,Segoe UI,Roboto,Arial;color:#006b80;text-decoration:none;padding:.35rem .6rem;border-radius:.5rem;border:1px solid #cfe9ee}
    .ts-mininav a:hover{background:#f2fbfd}
    .ts-spacer{flex:1}
    .wrap{max-width:840px;margin:1rem auto;padding:0 1rem}
    h1{font:600 22px/1.2 system-ui,-apple-system,Segoe UI,Roboto,Arial;margin:.75rem 0 1rem}
    label{display:block;font:600 14px/1.3 system-ui,-apple-system,Segoe UI,Roboto,Arial;margin:.8rem 0 .3rem}
    textarea{width:100%;min-height:88px;padding:.6rem;border:1px solid #d0d7de;border-radius:8px;font:14px/1.4 system-ui,-apple-system,Segoe UI,Roboto,Arial}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
    .actions{display:flex;gap:.75rem;margin-top:1rem}
    .ts-btn{display:inline-flex;align-items:center;gap:.4rem;padding:.55rem .9rem;border-radius:.6rem;border:1px solid #d0d7de;background:#fff;color:#222;text-decoration:none;cursor:pointer}
    .ts-btn.primary{background:#00bcd4;border-color:#00bcd4;color:#fff}
    form .hint{font-size:12px;color:#666;margin-top:.25rem}
  </style>
</head>
<body>
  <nav class="ts-mininav">
    <a href="/app/moodle/calendar/view.php?view=upcoming"><?php echo h($T['myclasses']); ?></a>
    <?php if ($courseid): ?><a href="/moodle/course/view.php?id=<?php echo (int)$courseid; ?>"><?php echo h($T['course']); ?></a><?php endif; ?>
    <?php if ($eventid):  ?><a href="/moodle/calendar/view.php?view=day&eventid=<?php echo (int)$eventid; ?>"><?php echo h($T['event']); ?></a><?php endif; ?>
    <div class="ts-spacer"></div>
    <a class="ts-btn" href="<?php echo h($returnUrl); ?>">← <?php echo h($T['back']); ?></a>
    <a class="ts-btn" href="mailto:soporte@tuspeaking.com"><?php echo h($T['support']); ?></a>
  </nav>

  <div class="wrap">
    <h1><?php echo h($T['formTitle']); ?></h1>

    <form method="post" action="">
      <!-- IDs esperados por tu backend -->
      <input type="hidden" name="acuityID"  value="<?php echo (int)$acuityID_get; ?>">
      <input type="hidden" name="studentID" value="<?php echo (int)$studentID_get; ?>">
      <input type="hidden" name="teacherID" value="<?php echo (int)$teacherID_get; ?>">
      <input type="hidden" name="lang"      value="<?php echo h($lang); ?>">

      <label for="topic"><?php echo h($T['topic']); ?></label>
      <textarea id="topic" name="topic" required></textarea>

      <label for="questions"><?php echo h($T['questions']); ?></label>
      <textarea id="questions" name="questions"></textarea>

      <div class="grid">
        <div>
          <label for="resource"><?php echo h($T['resource']); ?></label>
          <textarea id="resource" name="resource"></textarea>
        </div>
        <div>
          <label for="corrections"><?php echo h($T['corrections']); ?></label>
          <textarea id="corrections" name="corrections"></textarea>
        </div>
      </div>

      <div class="grid">
        <div>
          <label for="good"><?php echo h($T['good']); ?></label>
          <textarea id="good" name="good"></textarea>
        </div>
        <div>
          <label for="bad"><?php echo h($T['bad']); ?></label>
          <textarea id="bad" name="bad"></textarea>
        </div>
      </div>

      <label for="next"><?php echo h($T['next']); ?></label>
      <textarea id="next" name="next"></textarea>

      <label for="comments"><?php echo h($T['comments']); ?></label>
      <textarea id="comments" name="comments"></textarea>

      <div class="actions">
        <button type="submit" class="ts-btn primary">✅ <?php echo h($T['submit']); ?></button>
        <a class="ts-btn" href="<?php echo h($returnUrl); ?>">← <?php echo h($T['back']); ?></a>
      </div>

      <div class="hint">
        <!-- ayuda mínima; puedes eliminarla si prefieres 100% limpio -->
        <?php if ($lang==='es'): ?>
          <p>Nota: este formulario generará un PDF y lo adjuntará al evento de calendario correspondiente. Si abriste esta página desde tu calendario, el botón «Atrás» te llevará a la vista anterior.</p>
        <?php else: ?>
          <p>Note: this form will generate a PDF and attach it to the related calendar event. If you opened this page from your calendar, the “Back” button will take you to the previous view.</p>
        <?php endif; ?>
      </div>
    </form>
  </div>
</body>
</html>
