<?php
require('config.php');
require_once($CFG->dirroot.'/calendar/lib.php');		//Require para Moodle Calendar API
require_once "./askddbb.php";
require_once "./own_ZoomAPI.php";
$error = "";

if (!empty($_POST) || !empty($_GET)){
	
	if (!empty($_POST)){
		$acuityID = $_POST['id'];
	} else {
		$acuityID = $_GET['id'];
	}
			
	/***** Peticion a Acuity *****/
	/**** Credenciales ****/
		$userID = '15680788';
		$key = '7727321b66b8210424f1d4d984584693';
	/**** Fin credenciales ****/
	/*** URL para peticion por ID de appointment ***/
		$url = 'https://acuityscheduling.com/api/v1/appointments/' . $acuityID;
	/*** Fin URL ***/
	/*** Obtenemos la respuesta de la API ***/
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$userID:$key");
		$result = curl_exec($ch);
		curl_close($ch);
	/*** Fin respuesta API ***/
	/*** Transformamos el json en un array ***/
		$appointment = json_decode($result, true);
	//print_r($appointment);
	/*** Fin json ***/
	/** Recogemos los valores de las variables que le hemos pasado a Acuity desde Moodle ***/
		$locationURL = explode(" ", $appointment['location'])[1];
	//$locationID = explode(" ", $appointment['location'])[4];
		$confirmPage = $appointment['confirmationPage'];
		$calendarID = $appointment['calendarID'];
	/** Fin valores Moodle ***/
	/***** Fin peticion a Acuity *****/
	
	try {
		$conn = new PDO("mysql:host=".$CFG->dbhost.";dbname=".$CFG->dbname, $CFG->dbuser, $CFG->dbpass);
		// set the PDO error mode to exception
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		/** Consulta Select de los datos del evento **/
			/* Generamos sentencia SQL */
				$sql = "SELECT * FROM own_acuity WHERE acuityid = $acuityID";
			/* Fin SQL */
			/* Ejecutamos sentencia SQL */
				$stmt = $conn->prepare($sql); 
				$stmt->execute();
				$res = $stmt->fetch();
				$ownID = $res['id'];

				if ($ownID == "")
				{

					foreach ($appointment['forms'] as $key=>$value){
						// Cambiar el texto por el del Intake Form Questions que hayamos creado
						if ($value['name'] == "Form interno Moodle"){
							foreach($value['values'] as $k=>$v){
								// Añadir mas else if si metemos mas campos al Intake
								if($v['fieldID'] == 5837866){
									$studentID = $v['value'];
								} else if ($v['fieldID'] == 5915926){
									$courseID = $v['value'];
								}
							}
							break;
						}
					}

					if ($studentID == "" || $studentID == "1" || $courseID == "" || $courseID == "1") {
						goto fin;
					} else {
						$locationURL = explode(" ", $appointment['location'])[1];
						$locationID = explode(" ", $appointment['location'])[4];
						$locationID = str_replace("-","", $locationID);
						$confirmPage = $appointment['confirmationPage'];
						$calendarID = $appointment['calendarID'];
					/** Fin valores Moodle ***/
				/***** Segunda llamada a API de Acuity *****/
					/**** Credenciales ****/
						$userID = '15680788';
						$key = '7727321b66b8210424f1d4d984584693';
					/**** Fin credenciales ****/
					/*** URL para peticion de calendarios ***/
						$url = 'https://acuityscheduling.com/api/v1/calendars';
					/*** Fin URL ***/
					/*** Obtejenos la respuesta de la API ***/
						$ce = curl_init();
						curl_setopt($ce, CURLOPT_URL, $url);
						curl_setopt($ce, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ce, CURLOPT_USERPWD, "$userID:$key");
						$res = curl_exec($ce);
						curl_close($ce);
					/*** Fin respuesta API ***/
					/*** Transformamos el json en array ***/
						$calendars = json_decode($res, true);

						/*** Fin json ***/
					/** Recogemos los valores del calendario que nos interesa $calendarID ***/
						foreach ($calendars as $key=>$value) {
							if($value['id'] == $calendarID){
								$mails = explode(",", $value['email']);
								$teachermail = trim($mails[0]);
								break;
							}
						}

						/** Fin valores calendario ***/
						/** Filtramos los correos ***/
							if($teachermail == "alisonkilkenny@gmail.com"){
								$teachermail = "alison@live.tuspeaking.com";
							} else if ($teachermail == "mark.tobias22120484@gmail.com"){
								$teachermail = "mark@live.tuspeaking.com";
							//} else if ($teachermail == "tjdclarke@gmail.com"){
							} else if ($teachermail == "theo@tuspeaking.com"){
								$teachermail = "theo@live.tuspeaking.com";
							} else if ($teachermail == "unienglishteacher42@gmail.com"){
								$teachermail = "annie@live.tuspeaking.com";
							}
					//███████████████████████████████████████████████████████████████████████████QUITAR███████████████████████████████████████████████████████████████████████████
							else if ($teachermail == "hfernandez@live.tuspeaking.com"){
								$teachermail = "carmen@tuspeaking.com";
							}
						/** Fin filtrado correos ***/
					/***** Fin peticion a Acuity *****/
					$ourTime = time();

					/** Consulta Select del id del profesor **/
					/* Generamos sentencia SQL */
						$sql = "SELECT id FROM mdl_user WHERE email = '$teachermail'";

						/* Fin SQL */
						/* Ejecutamos sentencia SQL */
							$stmt = $conn->prepare($sql); 
							$stmt->execute();
							$teacherID = ($stmt->fetch())['id'];
						/* Fin ejecucion */
					/** Fin select **/
					/** Consulta Insert en los calendarios de Moodle **/
						/* Generamos sentencia SQL */
							$calName = escapeshellcmd($appointment['type']) . " " . escapeshellcmd($appointment['calendar']);
							if ($locationURL != "%location%"){
								$locTxt = "<br>URL: <a href=\'$locationURL\'  target=\'_blank\'>$locationURL</a>";		
							} else {
								$locTxt = "";
							}
							$confirmTxt = "<br><a href=\'$confirmPage\' target=\'_blank\' class=\'acuity-embed-button\' style=\'background: #00bcd4; color: #fff; padding: 8px 12px; border: 0px; -webkit-box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;-moz-box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;border-radius: 4px; text-decoration: none; display: inline-block;\'>Modificar/Cancelar Sesi&oacute;n</a>";
							$calDesc = $appointment['type'] . " (" . $appointment['firstName'] . " " . $appointment['lastName'] . ") " . $appointment['date'] . " " . $appointment['time'] . " - " . $appointment['endTime'] . " " . escapeshellcmd($appointment['calendar']) . $locTxt;
							$feedback = "<br><a href=\'https://aula.tuspeaking.com/app/moodle/formFeedback.php?acuityid=".$acuityID."\' target=\'_blank\' class=\'acuity-embed-button\' style=\'background: #00bcd4; color: #fff; padding: 8px 12px; border: 0px; -webkit-box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;-moz-box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;border-radius: 4px; text-decoration: none; display: inline-block;\'>Feedback</a>";
							$sql = "INSERT INTO mdl_event (name, description, format, categoryid, courseid, groupid, userid, repeatid, modulename, instance, type, eventtype, timestart, timeduration, visible, uuid, sequence, timemodified)";
							$sql .=	" VALUES ('$calName', '" . $calDesc . $confirmTxt . "', 1, 0, 0, 0, $studentID, 0, 0, 0, 0, 'user', " . strtotime($appointment['datetime']) . ", 0, 1, '', 1, $ourTime)"; // ID Estudiante
							$sql .= ", ('$calName', '".$calDesc.$feedback."', 1, 0, 0, 0, $teacherID, 0, 0, 0, 0, 'user', " . strtotime($appointment['datetime']) . ", 0, 1, '', 1, $ourTime)"; // ID Profesor
							$sql .= ", ('$calName', '$calDesc', 1, 0, 0, 0, 14, 0, 0, 0, 0, 'user', " . strtotime($appointment['datetime']) . ", 0, 1, '', 1, $ourTime)"; // ID de Hansel
							$sql .= ", ('$calName', '$calDesc', 1, 0, 0, 0, 2, 0, 0, 0, 0, 'user', " . strtotime($appointment['datetime']) . ", 0, 1, '', 1, $ourTime)";  // ID de Carmen
							$sql .= ", ('$calName', '$calDesc', 1, 0, 0, 0, 48, 0, 0, 0, 0, 'user', " . strtotime($appointment['datetime']) . ", 0, 1, '', 1, $ourTime)"; // ID de Guillermo
						/* Fin SQL */
						/* Ejecutamos sentencia SQL */
							$conn->exec($sql);
					/** Fin insert **/

						/** Consulta Select para obtener los ID de los eventos de Moodle **/
						/* Generamos sentencia SQL */
							$sql = "SELECT id FROM mdl_event WHERE (userid = $studentID OR userid = $teacherID OR userid = 14 OR userid = 2 OR userid = 48) AND timestart = " . strtotime($appointment['datetime']) . " AND timemodified = $ourTime";
							/* Fin SQL */
							/* Ejecutamos sentencia SQL */
								$stmt = $conn->prepare($sql); 
								$stmt->execute();
								$result = $stmt->fetchall();
								$userIDs = array();
								foreach ($result as $k=>$v){
									$userIDs[] = $v['id'];
								}
						/** Fin select **/
						/** Consulta si es FUNDAE o no */
						$fundaeid = askmysql("SELECT isfundae FROM own_acuity_course WHERE courseid = $courseID");
						$fundaeid = $fundaeid[0]['isfundae'];
						if ($fundaeid == "f"){
							$fundaeid = 'null';
						} else if ($fundaeid == "t"){
							$fundaeid = 161;
							$settings = json_encode(array("auto_recording" => "cloud"));
							$data = '{"settings":'.$settings.'}';
							patchZoom("https://api.zoom.us/v2/meetings/" . $locationID, $data);
						}
						/** Consulta Insert para almacenar el evento de Acuity **/
							/* Generamos sentencia SQL */
								$sql = "INSERT INTO own_acuity (acuityid, courseid, studentid, studenteventid, teacherid, teachereventid, fundaeid, heventid, ceventid, geventid, lastmodified) VALUES ($acuityID, $courseID, $studentID, $userIDs[0], $teacherID, $userIDs[1], $fundaeid, $userIDs[2], $userIDs[3], $userIDs[4], NOW())";
							/* Fin SQL */
							/* Ejecutamos sentencia SQL */
								$conn->exec($sql);
						/** Fin insert **/

						/** INSERT en mdl_i3code_acuityZoom (para Mis Clases) - Añadido 2026-01-26 **/
						$acuity_datetime = $appointment['datetime'];
						$acuity_firstname_q = $conn->quote($appointment['firstName']);
						$acuity_lastname_q = $conn->quote($appointment['lastName']);
						$acuity_phone_q = $conn->quote($appointment['phone']);
						$acuity_email_q = $conn->quote($appointment['email']);
						$acuity_type_q = $conn->quote($appointment['type']);
						$zoom_meetingid_val = !empty($locationID) ? $locationID : 'NULL';
						
						$sql_acuityZoom = "INSERT INTO mdl_i3code_acuityZoom 
							(acuityid, courseid, studentid, teacherid, acuity_firstname, acuity_lastname, acuity_phone, acuity_email, acuity_datetime, acuity_type, zoom_meetingid, zoom_clasecompletada, acuity_canceled, acuity_rescheduled)
							VALUES 
							($acuityID, $courseID, $studentID, $teacherID, $acuity_firstname_q, $acuity_lastname_q, $acuity_phone_q, $acuity_email_q, '$acuity_datetime', $acuity_type_q, $zoom_meetingid_val, 3, 0, 0)";
						$conn->exec($sql_acuityZoom);
						/** Fin INSERT mdl_i3code_acuityZoom **/
					}

				} else {
					$studentEventID = $res['studenteventid'];
					$teacherEventID = $res['teachereventid'];
					$heventid = $res['heventid'];
					$ceventid = $res['ceventid'];
					$geventid = $res['geventid'];
				/* Fin ejecucion */
			/** Fin select **/
			/** Consulta Update de los eventos de Moodle **/
				/* Generamos sentencia SQL */
					if ($locationURL != "%location%"){
						$locTxt = "<br>URL: <a href=\'$locationURL\'  target=\'_blank\'>$locationURL</a>";				
					} else {
						$locTxt = "";
					}
					$calDesc = $appointment['type'] . " (" . $appointment['firstName'] . " " . $appointment['lastName'] . ") " . $appointment['date'] . " " . $appointment['time'] . " - " . $appointment['endTime'] . " " . $appointment['calendar'] . $locTxt;
					$confirmTxt = "<br><a href=\'$confirmPage\' target=\'_blank\' class=\'acuity-embed-button\' style=\'background: #00bcd4; color: #fff; padding: 8px 12px; border: 0px; -webkit-box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;-moz-box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;border-radius: 4px; text-decoration: none; display: inline-block;\'>Modificar/Cancelar Sesi&oacute;n</a><script src=\'https://embed.acuityscheduling.com/embed/button/15680788.js\' async=\'\'></script>";
					if ($studentEventID != 0) {
						$sql = "UPDATE mdl_event SET description = '" . $calDesc . $confirmTxt . "', timestart = " . strtotime($appointment['datetime']) . " WHERE id = $studentEventID;";
					}
					if ($teacherEventID != 0) {
						$sql .= "UPDATE mdl_event SET description = '$calDesc', timestart = " . strtotime($appointment['datetime']) . " WHERE id = $teacherEventID";
					}
					if ($heventid != 0){
						$sql .= " OR id = $heventid";
					}
					if ($ceventid != 0){
						$sql .= " OR id = $ceventid";
					}
					if ($geventid != 0){
						$sql .= " OR id = $geventid";
					}
					$sql .= ";";

				/* Fin SQL */
				/* Ejecutamos sentencia SQL */
					$conn->exec($sql);
			/** Fin Update **/
			/** Consulta Update de own_acuity **/
				/* Generamos sentencia SQL */
					$sql = "UPDATE own_acuity SET modifiedtimes = modifiedtimes + 1, lastmodified = NOW() WHERE id = $ownID";
				/* Fin SQL */
				/* Ejecutamos sentencia SQL */
					$conn->exec($sql);
		/** Consulta Update de mdl_i3code_acuityZoom (para Mis Clases - Reprogramacion) **/
			$sql_acuity = "UPDATE mdl_i3code_acuityZoom SET acuity_rescheduled = 1, acuity_original_datetime = COALESCE(acuity_original_datetime, acuity_datetime), acuity_datetime = '" . $appointment['datetime'] . "' WHERE acuityid = $acuityID";
			$conn->exec($sql_acuity);
		/** Fin Update mdl_i3code_acuityZoom **/
			/** Fin Update **/
					}				
				/* Fin ejecucion */
			/** Fin select **/
	}
	catch (PDOException $e) {
		echo $e;
		$error .= "Error Base de Datos.<br>Sentencia SQL:<br>" . $sql . "<br>Error:<br>" . $e->getMessage() . "<br><br><br>";
	}
	finally {
		$conn = null;
	}

} else {
	$error .= "Error en m&eacute;todo POST.<br><br><br>";
}

err:
if ($error != "") {
	
	$recipient = "soporte.tuspeaking@gmail.com";
	// Set the email subject.
	$subject = "Error Acuity. New/Modify Event.";

	// Build the email content.
	$email_content = "Error en Appointment con ID: " . $acuityID . ".<br>Para intentar corregir el error pulse <a href='https://aula.tuspeaking.com/app/moodle/modifyAndCreateAcuity.php?acuityID=" . $acuityID . "'>aqu&iacute;</a>.<br><br>" . $error;

	// Build the email headers.
	$email_headers = 'MIME-Version: 1.0' . "\r\n";
	$email_headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";

	// Send the email.
	if (mail($recipient, $subject, $email_content, $email_headers)) {
		// Set a 200 (okay) response code.
		http_response_code(200);
		echo "Su mensaje ha sido enviado, le contestaremos tan pronto como nos sea posible.";
	} else {
		// Set a 500 (internal server error) response code.
		http_response_code(500);
		echo "¡Ups! Algo ha ido mal y su mensaje no ha sido enviado, vuelva a intentarlo pasados unos instantes.<br>Gracias.";
	}
	
}
fin:
?>
