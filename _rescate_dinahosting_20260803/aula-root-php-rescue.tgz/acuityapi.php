<?php
$userID = 15680788;
$apiKey = '7727321b66b8210424f1d4d984584693';
$baseUrl = "https://acuityscheduling.com/api/v1/";

if (isset($_POST['url'])){
	$url = $_POST['url'];
	$data = $_POST['data'];
	echo json_encode(callAPI($url, $data));
}

function callAPI($url, $data){
    global $userID, $apiKey, $baseUrl;
	$url = $baseUrl . $url;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERPWD, "$userID:$apiKey");
	if ($data != ""){
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	}
	$result = curl_exec($ch);
	curl_close($ch);
	$jsonresult = json_decode($result, true);
	return $jsonresult;
}

function putAPI($url, $data){
    global $userID, $apiKey, $baseUrl;
    $url = $baseUrl . $url;
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
    if ($data) {
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_USERPWD, "$userID:$apiKey");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    $result = curl_exec($curl);
    curl_close($curl);
    $jsonResult = json_decode($result, true);
    return $jsonResult;
}