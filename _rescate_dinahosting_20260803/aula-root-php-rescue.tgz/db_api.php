<?php
$token = $_GET['token'] ?? '';
if ($token !== 'ts_hansel_2026') { http_response_code(403); die('Forbidden'); }

$host = 'localhost';
$user = 'moodle35';
$pass = 'TuspeakingFix2025!';
$db   = 'aulatuspeaking35';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) { die(json_encode(['error' => $conn->connect_error])); }

$q = $_GET['q'] ?? '';
$result = $conn->query($q);
if (!$result) { die(json_encode(['error' => $conn->error])); }

$rows = [];
while ($row = $result->fetch_assoc()) $rows[] = $row;
header('Content-Type: application/json');
echo json_encode($rows);
