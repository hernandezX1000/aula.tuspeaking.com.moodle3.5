<?php
require('config.php');
$admins = get_admins();
$isadmin = false;
foreach($admins as $admin){
    if ($admin->id == $USER->id){ $isadmin = true; break; }
}
if (!$isadmin){ header("Location: /app/moodle"); die(); }

$output_dir = '/home/aulatuspeaking/scripts/coding_tuspeaking/output/';
$file = isset($_GET['f']) ? basename($_GET['f']) : '';

if ($file && file_exists($output_dir . $file)) {
    $filepath = $output_dir . $file;
    $ext = pathinfo($file, PATHINFO_EXTENSION);
    
    if ($ext === 'pdf') {
        header('Content-Type: application/pdf');
    } else {
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    }
    header('Content-Disposition: attachment; filename="' . $file . '"');
    header('Content-Length: ' . filesize($filepath));
    readfile($filepath);
    exit;
}

header("Location: coding_fundae.php");
