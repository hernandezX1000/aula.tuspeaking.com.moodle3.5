<?php
if (!defined('CLI_SCRIPT')) {
    define('CLI_SCRIPT', true);
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/vendor/autoload.php';
use \Firebase\JWT\JWT;

function generateJWT (int $duration = 30) {
    $key = 'MWXtMAaaSjCCzVuhPZ3KDg';
    $secret = 'yi4jcQSI0bJZRZTWwkLbgX7oez2qnKPaKuzd';
    $token = array(
        "iss" => $key,
        "exp" => time() + $duration
    );
   
    return JWT::encode($token, $secret);
}

function generateTokenOAuth () 
{

    $zoom_config = get_config('zoom');

    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://zoom.us/oauth/token?grant_type=account_credentials&account_id=' . $zoom_config->accountid,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_HTTPHEADER => array(
        'Authorization: Basic '. base64_encode($zoom_config->clientid.":".$zoom_config->clientsecret)
      ),
    ));

    $response = curl_exec($curl);
    if(curl_error($curl)){
        $response = curl_error($curl);
    }
	curl_close($curl);

    $token = json_decode($response)->access_token;

	return $token;
}
