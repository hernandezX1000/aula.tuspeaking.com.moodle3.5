<?php
require('config.php');
require_once($CFG->dirroot.'/calendar/lib.php');		//Require para Moodle Calendar API
$error = "";

if (!empty($_POST)){
	$acuityID = $_POST['id'];
	/***** Peticion a Acuity *****/
		/**** Credenciales ****/
			$userID = '15680788';
			$key = '7727321b66b8210424f1d4d984584693';
		/**** Fin credenciales ****/
		/*** URL para peticion por ID de appointment ***/
			$url = 'https://acuityscheduling.com/api/v1/appointments/' . $acuityID;
		/*** Fin URL ***/
		/*** Obtenemos la respuesta de la API ***/
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$userID:$key");
			$result = curl_exec($ch);
			curl_close($ch);
		/*** Fin respuesta API ***/
		/*** Transformamos el json en un array ***/
			$appointment = json_decode($result, true);
			//print_r($appointment);
		/*** Fin json ***/
		/** Recogemos los valores de las variables que le hemos pasado a Acuity desde Moodle ***/
			$locationURL = explode(" ", $appointment['location'])[1];
			//$locationID = explode(" ", $appointment['location'])[4];
			$confirmPage = $appointment['confirmationPage'];
			$calendarID = $appointment['calendarID'];
		/** Fin valores Moodle ***/
	/***** Fin peticion a Acuity *****/
	
	try {
		$conn = new PDO("mysql:host=".$CFG->dbhost.";dbname=".$CFG->dbname, $CFG->dbuser, $CFG->dbpass);
		// set the PDO error mode to exception
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		/** Consulta Select de los datos del evento **/
			/* Generamos sentencia SQL */
				$sql = "SELECT id, studenteventid, teachereventid, heventid, ceventid, geventid FROM own_acuity WHERE acuityid = $acuityID";
			/* Fin SQL */
			/* Ejecutamos sentencia SQL */
				$stmt = $conn->prepare($sql); 
				$stmt->execute();
				$res = $stmt->fetch();
				$ownID = $res['id'];
				if ($ownID == ""){
					goto fin;
				}
				$studentEventID = $res['studenteventid'];
				$teacherEventID = $res['teachereventid'];
				$heventid = $res['heventid'];
				$ceventid = $res['ceventid'];
				$geventid = $res['geventid'];
			/* Fin ejecucion */
		/** Fin select **/
		/** Consulta Update de los eventos de Moodle **/
			/* Generamos sentencia SQL */
				if ($locationURL != "%location%"){
					$locTxt = "<br>URL: <a href=\'$locationURL\'  target=\'_blank\'>$locationURL</a>";					
				} else {
					$locTxt = "";
				}
				$calDesc = $appointment['type'] . " (" . $appointment['firstName'] . " " . $appointment['lastName'] . ") " . $appointment['date'] . " " . $appointment['time'] . " - " . $appointment['endTime'] . " " . $appointment['calendar'] . $locTxt;
				$confirmTxt = "<br><a href=\'$confirmPage\' target=\'_blank\' class=\'acuity-embed-button\' style=\'background: #00bcd4; color: #fff; padding: 8px 12px; border: 0px; -webkit-box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;-moz-box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;box-shadow: 0 -2px 0 rgba(0,0,0,0.15) inset;border-radius: 4px; text-decoration: none; display: inline-block;\'>Modificar/Cancelar Sesi&oacute;n</a><script src=\'https://embed.acuityscheduling.com/embed/button/15680788.js\' async=\'\'></script>";
				if ($studentEventID != 0) {
					$sql = "UPDATE mdl_event SET description = '" . $calDesc . $confirmTxt . "', timestart = " . strtotime($appointment['datetime']) . " WHERE id = $studentEventID;";
				}
				if ($teacherEventID != 0) {
					$sql .= "UPDATE mdl_event SET description = '$calDesc', timestart = " . strtotime($appointment['datetime']) . " WHERE id = $teacherEventID";
				}
				if ($heventid != 0){
					$sql .= " OR id = $heventid";
				}
				if ($ceventid != 0){
					$sql .= " OR id = $ceventid";
				}
				if ($geventid != 0){
					$sql .= " OR id = $geventid";
				}
				$sql .= ";";

			/* Fin SQL */
			/* Ejecutamos sentencia SQL */
				$conn->exec($sql);
		/** Fin Update **/
		/** Consulta Update de own_acuity **/
			/* Generamos sentencia SQL */
				$sql = "UPDATE own_acuity SET modifiedtimes = modifiedtimes + 1, lastmodified = NOW() WHERE id = $ownID";
			/* Fin SQL */
			/* Ejecutamos sentencia SQL */
				$conn->exec($sql);
		/** Fin Update **/
	}
	catch (PDOException $e) {
		$error .= "Error Base de Datos.<br>Sentencia SQL:<br>" . $sql . "<br>Error:<br>" . $e->getMessage() . "<br><br><br>";
	}
	finally {
		$conn = null;
	}

} else {
	$error .= "Error en m&eacute;todo POST.<br><br><br>";
}

if ($error != ""){
	$recipient = "soporte.tuspeaking@gmail.com";
	// Set the email subject.
	$subject = "Error Acuity. Modify Event.";

	// Build the email content.
	$email_content = "Error en Appointment con ID: " . $acuityID . ".<br>Para intentar corregir el error pulse <a href='https://aula.tuspeaking.com/app/moodle/prueba1.php?acuityID=" . $acuityID . "'>aqu&iacute;</a>.<br><br>" . $error;

	// Build the email headers.
	$email_headers = 'MIME-Version: 1.0' . "\r\n";
	$email_headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";

	// Send the email.
	if (mail($recipient, $subject, $email_content, $email_headers)) {
		// Set a 200 (okay) response code.
		http_response_code(200);
		echo "Su mensaje ha sido enviado, le contestaremos tan pronto como nos sea posible.";
	} else {
		// Set a 500 (internal server error) response code.
		http_response_code(500);
		echo "¡Ups! Algo ha ido mal y su mensaje no ha sido enviado, vuelva a intentarlo pasados unos instantes.<br>Gracias.";
	}
}
fin:
?>