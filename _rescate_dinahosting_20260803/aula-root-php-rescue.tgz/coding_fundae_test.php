<?php
require('config.php');
$admins = get_admins();
$isadmin = false;
foreach($admins as $admin){
    if ($admin->id == $USER->id){ $isadmin = true; break; }
}
if (!$isadmin){ header("Location: /app/moodle"); die(); }

echo "<h2>Test de Generación FUNDAE</h2>";
echo "<pre>";

$upload_dir = '/home/aulatuspeaking/scripts/coding_tuspeaking/uploads/';
$output_dir = '/home/aulatuspeaking/scripts/coding_tuspeaking/output/';
$script = '/home/aulatuspeaking/scripts/coding_tuspeaking/coding_fundae_report_generator.py';

echo "Upload dir: $upload_dir\n";
echo "Output dir: $output_dir\n";
echo "Script: $script\n";
echo "Upload dir exists: " . (file_exists($upload_dir) ? "YES" : "NO") . "\n";
echo "Upload dir writable: " . (is_writable($upload_dir) ? "YES" : "NO") . "\n";
echo "Script exists: " . (file_exists($script) ? "YES" : "NO") . "\n";

if ($_POST && isset($_FILES['f'])) {
    echo "\n--- FILE UPLOAD ---\n";
    print_r($_FILES['f']);
    
    $file = $_FILES['f'];
    if ($file['error'] === 0) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $fn = 'rep_'.date('Ymd_His').'.'.$ext;
        $fp = $upload_dir.$fn;
        
        echo "\nDestination: $fp\n";
        
        if (move_uploaded_file($file['tmp_name'], $fp)) {
            echo "File uploaded OK!\n";
            echo "File exists: " . (file_exists($fp) ? "YES" : "NO") . "\n";
            
            $cmd = "/usr/bin/python3 $script $fp $output_dir 2>&1";
            echo "\nCommand: $cmd\n";
            echo "\n--- PYTHON OUTPUT ---\n";
            $out = shell_exec($cmd);
            echo $out;
            
            echo "\n--- OUTPUT FILES ---\n";
            $files = glob($output_dir.'FUNDAE_*');
            print_r($files);
        } else {
            echo "ERROR: Could not move uploaded file!\n";
        }
    } else {
        echo "Upload error code: " . $file['error'] . "\n";
    }
} else {
    echo "\nNo file uploaded yet.\n";
}
echo "</pre>";
?>
<hr>
<form method="POST" enctype="multipart/form-data">
<input type="file" name="f" accept=".xlsx,.xls,.csv">
<button type="submit">Test Upload</button>
</form>
