<?php
/**
 * FUNDAE — Exportar Libro de Calificaciones
 * Genera PDF con actividades y notas de un alumno
 */

require_once(__DIR__ . '/config.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

$mensaje = '';
$error   = '';
$archivo_generado = null;
$output_dir = '/home/aulatuspeaking/www/app/moodle/reportes_fundae';

// Crear directorio si no existe
if (!is_dir($output_dir)) {
    mkdir($output_dir, 0755, true);
}

// ── Descarga ──────────────────────────────────────────────────────────────────
if (isset($_GET['descargar']) && isset($_GET['archivo'])) {
    $archivo = $output_dir . '/' . basename($_GET['archivo']);
    if (file_exists($archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'pdf') {
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . basename($archivo) . '"');
        header('Content-Length: ' . filesize($archivo));
        readfile($archivo);
        exit;
    }
}

// ── Generar ───────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email     = trim($_POST['email'] ?? '');
    $course_id = intval($_POST['course_id'] ?? 0);
    $nombre    = trim($_POST['nombre'] ?? '');
    $fundae    = strtoupper(trim($_POST['fundae'] ?? ''));
    $nivel     = trim($_POST['nivel'] ?? '');

    if (!$email || !$course_id) {
        $error = 'Email y Course ID son obligatorios.';
    } else {
        // Buscar user_id en BD
        global $DB;
        $user = $DB->get_record('user', ['email' => $email], 'id, firstname, lastname');
        if (!$user) {
            $error = "Usuario no encontrado: $email";
        } else {
            $user_id    = $user->id;
            $nombre_real = $nombre ?: ($user->firstname . ' ' . $user->lastname);
            $slug       = str_replace(['@', '.'], ['_', '_'], explode('@', $email)[0]);
            $ts         = date('Ymd_His');
            $fname      = "Doc_Calificaciones_{$slug}_{$ts}.pdf";

            $script = '/home/aulatuspeaking/gen_calificaciones_single.py';

            $cmd = "PYTHONPATH=/home/aulatuspeaking/.local/lib/python3.9/site-packages "
                 . "/usr/bin/python3 " . escapeshellarg($script)
                 . " --email " . escapeshellarg($email)
                 . " --user_id " . escapeshellarg($user_id)
                 . " --course_id " . escapeshellarg($course_id)
                 . " --nombre " . escapeshellarg($nombre_real)
                 . " --fundae " . escapeshellarg($fundae)
                 . " --nivel " . escapeshellarg($nivel)
                 . " --output " . escapeshellarg($output_dir)
                 . " --filename " . escapeshellarg($fname)
                 . " 2>&1";

            $output     = [];
            $return_var = 0;
            exec($cmd, $output, $return_var);
            $output_text = implode("\n", $output);

            if ($return_var === 0 && file_exists($output_dir . '/' . $fname)) {
                $archivo_generado = $fname;
                $mensaje = "PDF generado correctamente para $nombre_real";
            } else {
                $error = "Error al generar PDF: " . $output_text;
            }
        }
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="https://aula.tuspeaking.com/app/moodle/theme/image.php/lambda/theme/1547126939/favicon">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" crossorigin="anonymous">
    <title>FUNDAE — Calificaciones | tuSpeaking</title>
    <style>
        :root { --tus-primary: #008ba3; --tus-secondary: #00bcd4; --tus-dark: #454545; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; color: var(--tus-dark); margin: 0; }
        header { background: linear-gradient(135deg, var(--tus-primary), var(--tus-secondary)); padding: 15px 30px; }
        .header-content { display: flex; justify-content: space-between; align-items: center; max-width: 1200px; margin: 0 auto; }
        .logo { font-size: 26px; color: white; font-weight: 300; }
        .logo span { font-weight: 600; }
        header h2 { color: white; font-size: 18px; font-weight: 400; margin: 0; }
        header a { color: white; background: rgba(255,255,255,0.2); padding: 8px 16px; border-radius: 4px; text-decoration: none; }
        header a:hover { background: rgba(255,255,255,0.3); color: white; }
        main { max-width: 750px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; border: none; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .card-header { background: var(--tus-secondary); color: white; padding: 15px 20px; font-size: 16px; font-weight: 500; border-radius: 8px 8px 0 0; }
        .card-body { padding: 20px; }
        .btn-primary { background: var(--tus-primary); border-color: var(--tus-primary); }
        .btn-primary:hover { background: #007a8f; border-color: #007a8f; }
        .btn-download { display: inline-block; background: #28a745; color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: 500; margin-top: 10px; }
        .btn-download:hover { background: #218838; color: white; }
        .ref-table { font-size: 13px; }
        .ref-table td, .ref-table th { padding: 5px 8px; }
    </style>
</head>
<body>
<header>
    <div class="header-content">
        <div class="logo">tu<span>Speaking</span></div>
        <h2>📊 FUNDAE — Libro de Calificaciones</h2>
        <a href="/app/moodle/admin-panel/"><i class="fas fa-arrow-left"></i> Panel</a>
    </div>
</header>

<main>
    <?php if ($mensaje): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> <?= htmlspecialchars($mensaje) ?>
        <?php if ($archivo_generado): ?>
        <br><a href="?descargar=1&archivo=<?= urlencode($archivo_generado) ?>" class="btn-download">
            <i class="fas fa-download"></i> Descargar PDF
        </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">📊 Generar libro de calificaciones</div>
        <div class="card-body">
            <form method="POST">
                <div class="form-group">
                    <label>Email del alumno <span class="text-danger">*</span></label>
                    <input type="email" name="email" class="form-control" placeholder="alumno@empresa.com" required>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Course ID (Moodle) <span class="text-danger">*</span></label>
                        <input type="number" name="course_id" class="form-control" placeholder="3110" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label>Código AF <small class="text-muted">(opcional)</small></label>
                        <input type="text" name="fundae" class="form-control" placeholder="AF001-01" style="text-transform:uppercase">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Nivel <small class="text-muted">(opcional)</small></label>
                        <select name="nivel" class="form-control">
                            <option value="">— Seleccionar —</option>
                            <option value="B1">B1</option>
                            <option value="Intermediate (B1-B2)">Intermediate (B1-B2)</option>
                            <option value="Advanced (C1)">Advanced (C1)</option>
                            <option value="C2">C2</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Nombre completo <small class="text-muted">(opcional, se detecta automáticamente)</small></label>
                    <input type="text" name="nombre" class="form-control" placeholder="Nombre Apellidos">
                </div>
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-file-pdf"></i> Generar PDF
                </button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">📋 Referencia — e2y Commerce 2026</div>
        <div class="card-body p-0">
            <table class="table table-sm ref-table mb-0">
                <thead class="thead-light">
                    <tr><th>Alumno</th><th>Email</th><th>Course ID</th><th>AF</th><th>Nivel</th></tr>
                </thead>
                <tbody>
                    <tr><td>Adrián Barrena</td><td>adrian.barrena@e2ycommerce.com</td><td>3110</td><td>AF002-01</td><td>Advanced (C1)</td></tr>
                    <tr><td>Andrea Landa</td><td>andrea.landa@e2ycommerce.com</td><td>3112</td><td>AF001-01</td><td>Intermediate (B1-B2)</td></tr>
                    <tr><td>Roberto Gotor</td><td>roberto.gotor@e2ycommerce.com</td><td>3111</td><td>AF002-02</td><td>Advanced (C1)</td></tr>
                    <tr><td>Francisco Sánchez</td><td>francisco.sanchez@e2ycommerce.com</td><td>3113</td><td>AF003-01</td><td>Intermediate (B1-B2)</td></tr>
                    <tr><td>Nieves Sancho</td><td>nieves.sancho@e2ycommerce.com</td><td>3114</td><td>AF004-01</td><td>Advanced (C1)</td></tr>
                    <tr><td>José Tomás Morán</td><td>jose.moran@e2ycommerce.com</td><td>3129</td><td>AF005-01</td><td>B1</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</main>
</body>
</html>
