<?php
require('config.php');
$admins = get_admins();
$isadmin = false;
foreach($admins as $admin){
    if ($admin->id == $USER->id){ $isadmin = true; break; }
}
if (!$isadmin){ header("Location: /app/moodle"); die(); }

echo "<h2>Test Python desde PHP</h2><pre>";

// Test 1: shell_exec disponible?
echo "1. shell_exec disponible: ";
if (function_exists('shell_exec')) {
    echo "SI\n";
} else {
    echo "NO - DESHABILITADO!\n";
}

// Test 2: Ejecutar comando simple
echo "\n2. Test whoami:\n";
$out = shell_exec('whoami 2>&1');
echo $out ? $out : "(sin output)";

// Test 3: Ejecutar Python
echo "\n3. Test Python version:\n";
$out = shell_exec('/usr/bin/python3 --version 2>&1');
echo $out ? $out : "(sin output)";

// Test 4: Ejecutar script
echo "\n4. Test script FUNDAE:\n";
$script = '/home/aulatuspeaking/scripts/coding_tuspeaking/coding_fundae_report_generator.py';
$out = shell_exec("/usr/bin/python3 $script 2>&1");
echo $out ? $out : "(sin output)";

echo "</pre>";
?>
