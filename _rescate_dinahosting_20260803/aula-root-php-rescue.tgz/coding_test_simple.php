<?php
require('config.php');
echo "<h2>Test Simple Upload</h2><pre>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "POST recibido!\n";
    echo "FILES: ";
    print_r($_FILES);
    echo "\nPOST: ";
    print_r($_POST);
}
echo "</pre>";
?>
<form method="POST" enctype="multipart/form-data">
<input type="file" name="archivo">
<input type="submit" value="Enviar">
</form>
