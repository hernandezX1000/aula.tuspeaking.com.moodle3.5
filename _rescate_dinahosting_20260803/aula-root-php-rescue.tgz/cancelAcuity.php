<?php
// === LOG DE CANCELACIONES (añadido 2026-01-20) ===
function log_cancelacion($msg) {
    $log_file = "/home/aulatuspeaking/www/app/moodle/logs/cancelaciones_acuity.log";
    $timestamp = date("Y-m-d H:i:s");
    file_put_contents($log_file, "[$timestamp] $msg\n", FILE_APPEND);
}
// === FIN LOG ===
require('config.php');
require_once($CFG->dirroot.'/calendar/lib.php');		//Require para Moodle Calendar API
$error = "";

if (!empty($_POST)){
	$acuityID = $_POST['id'];
	log_cancelacion("RECIBIDO: Acuity ID = $acuityID");
	/***** Peticion a Acuity *****/
		/**** Credenciales ****/
			$userID = '15680788';
			$key = '7727321b66b8210424f1d4d984584693';
		/**** Fin credenciales ****/
		/*** URL para peticion por ID de appointment ***/
			$url = 'https://acuityscheduling.com/api/v1/appointments/' . $acuityID;
		/*** Fin URL ***/
		/*** Obtenemos la respuesta de la API ***/
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$userID:$key");
			$result = curl_exec($ch);
			curl_close($ch);
		/*** Fin respuesta API ***/
		/*** Transformamos el json en un array ***/
			$appointment = json_decode($result, true);
			//print_r($appointment);
		/*** Fin json ***/
	/***** Fin peticion a Acuity *****/
	
	try {
		$conn = new PDO("mysql:host=".$CFG->dbhost.";dbname=".$CFG->dbname, $CFG->dbuser, $CFG->dbpass);
		// set the PDO error mode to exception
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		/** Consulta Select de los datos del evento **/
			/* Generamos sentencia SQL */
				$sql = "SELECT id, studenteventid, teachereventid, heventid, ceventid, geventid FROM own_acuity WHERE acuityid = $acuityID";
			/* Fin SQL */
			/* Ejecutamos sentencia SQL */
				$stmt = $conn->prepare($sql); 
				$stmt->execute();
				$res = $stmt->fetch();
				$ownID = $res['id'];
				if ($ownID == ""){
					goto fin;
				}
				$studentEventID = $res['studenteventid'];
				$teacherEventID = $res['teachereventid'];
				$heventid = $res['heventid'];
				$ceventid = $res['ceventid'];
				$geventid = $res['geventid'];
			/* Fin ejecucion */
		/** Fin select **/
		/** Consulta Delete de los eventos de profesor y estudiante **/
			/* Generamos sentencia SQL */
				if ($studentEventID != 0){
					$sql = "UPDATE mdl_event SET visible=0 WHERE id = $studentEventID";
				}
				if ($teacherEventID != 0){
					$sql .= " OR id = $teacherEventID";
				}
				if ($heventid != 0){
					$sql .= " OR id = $heventid";
				}
				if ($ceventid != 0){
					$sql .= " OR id = $ceventid";
				}
				if ($geventid != 0){
					$sql .= " OR id = $geventid";
				}
			/* Fin SQL */
			/* Ejecutamos sentencia SQL */
				$conn->exec($sql);
		/** Fin Delete **/
		/** Consulta Update de own_acuity **/
			/* Generamos consulta SQL */
				$sql = "UPDATE own_acuity SET modifiedtimes = modifiedtimes + 1, iscancelled = 't', lastmodified = NOW() WHERE id = $ownID";
			/* Fin SQL */
			/* Ejecutamos sentencia SQL */
				$conn->exec($sql);
		/** Fin Update **/
		/** Consulta Update de mdl_i3code_acuityZoom (para Mis Clases) **/
			$sql_acuity = "UPDATE mdl_i3code_acuityZoom SET acuity_canceled = 1 WHERE acuityid = $acuityID";
		log_cancelacion("ACTUALIZADO mdl_i3code_acuityZoom: acuity_canceled=1 para acuityid=$acuityID");
			$conn->exec($sql_acuity);
		/** Fin Update mdl_i3code_acuityZoom **/
		unlink("/home/aulatuspeaking/www/app/moodle/pdf/" . $acuityID . ".pdf");
	}
	catch (PDOException $e) {
		$error .= "Error Base de Datos.<br>Sentencia SQL:<br>" . $sql . "<br>Error:<br>" . $e->getMessage() . "<br><br><br>";
	}
	finally {
		$conn = null;
	}

} else {
	$error .= "Error en m&eacute;todo POST.<br><br><br>";
}

if ($error != ""){
	$recipient = "soporte.tuspeaking@gmail.com";
	// Set the email subject.
	$subject = "Error Acuity. Cancel Appointment.";

	// Build the email content.
	$email_content = "Error en Appointment con ID: " . $_POST['acuityID'] . ".<br>Para intentar corregir el error pulse <a href='https://aula.tuspeaking.com/app/moodle/prueba1.php?acuityID=" . $_POST['acuityID'] . "'>aqu&iacute;</a>.<br><br>" . $error;

	// Build the email headers.
	$email_headers = 'MIME-Version: 1.0' . "\r\n";
	$email_headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";

	// Send the email.
	if (mail($recipient, $subject, $email_content, $email_headers)) {
		// Set a 200 (okay) response code.
		http_response_code(200);
		echo "Su mensaje ha sido enviado, le contestaremos tan pronto como nos sea posible.";
	} else {
		// Set a 500 (internal server error) response code.
		http_response_code(500);
		echo "¡Ups! Algo ha ido mal y su mensaje no ha sido enviado, vuelva a intentarlo pasados unos instantes.<br>Gracias.";
	}
}
fin:
?>