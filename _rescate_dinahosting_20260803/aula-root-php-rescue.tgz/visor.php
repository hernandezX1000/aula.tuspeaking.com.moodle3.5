<?php
/**
 * Visor de presentaciones PPT
 * Usa Microsoft Office Online Viewer
 */

$archivo = $_GET['file'] ?? '';
$base_url = 'https://aula.tuspeaking.com/app/moodle/contenido/business_english/';
$ruta_local = '/home/aulatuspeaking/www/app/moodle/contenido/business_english/' . basename($archivo);

// Validar que el archivo existe
if (empty($archivo) || !file_exists($ruta_local)) {
    die('Archivo no encontrado');
}

$url_archivo = $base_url . rawurlencode(basename($archivo));

// Usar Microsoft Office Online Viewer
$visor_url = 'https://view.officeapps.live.com/op/embed.aspx?src=' . urlencode($url_archivo);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars(basename($archivo, '.pptx')) ?></title>
    <style>
        * { margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; }
        .header { background: #008ba3; color: white; padding: 10px 20px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 18px; font-weight: normal; }
        .header a { color: white; text-decoration: none; background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 4px; }
        .header a:hover { background: rgba(255,255,255,0.3); }
        iframe { width: 100%; height: calc(100vh - 50px); border: none; }
    </style>
</head>
<body>
    <div class="header">
        <h1><?= htmlspecialchars(basename($archivo, '.pptx')) ?></h1>
        <a href="<?= htmlspecialchars($url_archivo) ?>" download>⬇ Descargar</a>
    </div>
    <iframe src="<?= $visor_url ?>" allowfullscreen></iframe>
</body>
</html>
