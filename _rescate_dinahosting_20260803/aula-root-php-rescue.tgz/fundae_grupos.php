<?php
/**
 * FUNDAE — Gestión de Grupos AF en Moodle
 * Crea grupos con código AF y asigna alumnos
 */

require_once(__DIR__ . '/config.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

global $DB;

$mensaje = '';
$error = '';
$resultados = [];

// ── Procesar formulario ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $modo = $_POST['modo'] ?? 'individual';

    $entradas = [];

    if ($modo === 'individual') {
        $email     = trim($_POST['email'] ?? '');
        $course_id = intval($_POST['course_id'] ?? 0);
        $af_code   = strtoupper(trim($_POST['af_code'] ?? ''));
        if ($email && $course_id && $af_code) {
            $entradas[] = ['email' => $email, 'course_id' => $course_id, 'af_code' => $af_code];
        } else {
            $error = 'Rellena todos los campos.';
        }
    } elseif ($modo === 'csv') {
        $lineas = explode("\n", trim($_POST['csv_data'] ?? ''));
        foreach ($lineas as $linea) {
            $linea = trim($linea);
            if (!$linea || strpos($linea, '#') === 0) continue;
            $partes = array_map('trim', explode(',', $linea));
            if (count($partes) >= 3) {
                $entradas[] = [
                    'email'     => $partes[0],
                    'course_id' => intval($partes[1]),
                    'af_code'   => strtoupper($partes[2]),
                ];
            }
        }
        if (empty($entradas)) $error = 'CSV vacío o formato incorrecto.';
    }

    if (!$error) {
        foreach ($entradas as $e) {
            $resultado = ['email' => $e['email'], 'course_id' => $e['course_id'], 'af_code' => $e['af_code']];

            // 1. Buscar usuario
            $user = $DB->get_record('user', ['email' => $e['email']], 'id, firstname, lastname');
            if (!$user) {
                $resultado['status'] = 'error';
                $resultado['msg']    = 'Usuario no encontrado';
                $resultados[] = $resultado;
                continue;
            }
            $resultado['nombre'] = $user->firstname . ' ' . $user->lastname;

            // 2. Verificar curso
            $course = $DB->get_record('course', ['id' => $e['course_id']], 'id, fullname');
            if (!$course) {
                $resultado['status'] = 'error';
                $resultado['msg']    = 'Curso no encontrado';
                $resultados[] = $resultado;
                continue;
            }
            $resultado['curso'] = $course->fullname;

            // 3. Crear o recuperar grupo
            $group = $DB->get_record('groups', ['courseid' => $e['course_id'], 'idnumber' => $e['af_code']]);
            if (!$group) {
                $group = new stdClass();
                $group->courseid      = $e['course_id'];
                $group->name          = $e['af_code'];
                $group->idnumber      = $e['af_code'];
                $group->timecreated   = time();
                $group->timemodified  = time();
                $group->id = $DB->insert_record('groups', $group);
                $resultado['grupo_creado'] = true;
            } else {
                $resultado['grupo_creado'] = false;
            }

            // 4. Asignar alumno al grupo
            $ya_miembro = $DB->record_exists('groups_members', [
                'groupid' => $group->id,
                'userid'  => $user->id,
            ]);
            if (!$ya_miembro) {
                $member = new stdClass();
                $member->groupid   = $group->id;
                $member->userid    = $user->id;
                $member->timeadded = time();
                $member->component = '';
                $member->itemid    = 0;
                $DB->insert_record('groups_members', $member);
                $resultado['alumno_asignado'] = true;
            } else {
                $resultado['alumno_asignado'] = false;
            }

            $resultado['status'] = 'ok';
            $resultado['msg']    = '';
            $resultados[] = $resultado;
        }

        $ok  = count(array_filter($resultados, function($r) { return $r['status'] === 'ok'; }));
        $ko  = count($resultados) - $ok;
        $mensaje = "Procesados: {$ok} OK" . ($ko ? ", {$ko} con error" : '');
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="https://aula.tuspeaking.com/app/moodle/theme/image.php/lambda/theme/1547126939/favicon">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" crossorigin="anonymous">
    <title>FUNDAE — Grupos AF | tuSpeaking</title>
    <style>
        :root { --tus-primary: #008ba3; --tus-secondary: #00bcd4; --tus-dark: #454545; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; color: var(--tus-dark); margin: 0; }
        header { background: linear-gradient(135deg, var(--tus-primary), var(--tus-secondary)); padding: 15px 30px; }
        .header-content { display: flex; justify-content: space-between; align-items: center; max-width: 1200px; margin: 0 auto; }
        .logo { font-size: 26px; color: white; font-weight: 300; }
        .logo span { font-weight: 600; }
        header h2 { color: white; font-size: 18px; font-weight: 400; margin: 0; }
        header a { color: white; background: rgba(255,255,255,0.2); padding: 8px 16px; border-radius: 4px; text-decoration: none; }
        header a:hover { background: rgba(255,255,255,0.3); color: white; }
        main { max-width: 800px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; border: none; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .card-header { background: var(--tus-secondary); color: white; padding: 15px 20px; font-size: 16px; font-weight: 500; border-radius: 8px 8px 0 0; }
        .card-body { padding: 20px; }
        .btn-primary { background: var(--tus-primary); border-color: var(--tus-primary); }
        .btn-primary:hover { background: #007a8f; border-color: #007a8f; }
        .nav-tabs .nav-link.active { color: var(--tus-primary); border-bottom-color: var(--tus-primary); font-weight: 600; }
        .badge-ok { background: #28a745; color: white; padding: 3px 8px; border-radius: 4px; font-size: 12px; }
        .badge-error { background: #dc3545; color: white; padding: 3px 8px; border-radius: 4px; font-size: 12px; }
        .badge-new { background: #007bff; color: white; padding: 3px 8px; border-radius: 4px; font-size: 11px; }
        .badge-exists { background: #6c757d; color: white; padding: 3px 8px; border-radius: 4px; font-size: 11px; }
        table { font-size: 14px; }
        textarea { font-family: monospace; font-size: 13px; }
    </style>
</head>
<body>
<header>
    <div class="header-content">
        <div class="logo">tu<span>Speaking</span></div>
        <h2>🗂️ FUNDAE — Gestión de Grupos AF</h2>
        <a href="/app/moodle/admin-panel/"><i class="fas fa-arrow-left"></i> Panel</a>
    </div>
</header>

<main>
    <?php if ($mensaje): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($mensaje) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">📋 Asignar código AF a alumno en curso</div>
        <div class="card-body">
            <ul class="nav nav-tabs mb-3" id="modoTab">
                <li class="nav-item">
                    <a class="nav-link active" id="tab-individual" href="#" onclick="setModo('individual')">Individual</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="tab-csv" href="#" onclick="setModo('csv')">Masivo (CSV)</a>
                </li>
            </ul>

            <form method="POST">
                <input type="hidden" name="modo" id="modo_input" value="individual">

                <!-- Individual -->
                <div id="panel-individual">
                    <div class="form-group">
                        <label>Email del alumno</label>
                        <input type="email" name="email" class="form-control" placeholder="andrea.landa@e2ycommerce.com">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Course ID (Moodle)</label>
                            <input type="number" name="course_id" class="form-control" placeholder="3112">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Código AF</label>
                            <input type="text" name="af_code" class="form-control" placeholder="AF001-01" style="text-transform:uppercase">
                        </div>
                    </div>
                </div>

                <!-- CSV -->
                <div id="panel-csv" style="display:none">
                    <div class="form-group">
                        <label>Datos CSV <small class="text-muted">(formato: email, course_id, codigo_af — una línea por alumno)</small></label>
                        <textarea name="csv_data" class="form-control" rows="8" placeholder="andrea.landa@e2ycommerce.com,3112,AF001-01
roberto.gotor@e2ycommerce.com,3111,AF002-02
francisco.sanchez@e2ycommerce.com,3113,AF003-01
nieves.sancho@e2ycommerce.com,3114,AF004-01
jose.moran@e2ycommerce.com,3129,AF005-01"></textarea>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-users"></i> Crear grupos y asignar
                </button>
            </form>
        </div>
    </div>

    <?php if (!empty($resultados)): ?>
    <div class="card">
        <div class="card-header">✅ Resultados</div>
        <div class="card-body p-0">
            <table class="table table-hover mb-0">
                <thead class="thead-light">
                    <tr>
                        <th>Estado</th>
                        <th>Alumno</th>
                        <th>Email</th>
                        <th>Curso</th>
                        <th>Grupo AF</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($resultados as $r): ?>
                    <tr>
                        <td>
                            <?php if ($r['status'] === 'ok'): ?>
                                <span class="badge-ok">✓ OK</span>
                            <?php else: ?>
                                <span class="badge-error">✗ Error</span>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($r['nombre'] ?? '—') ?></td>
                        <td><small><?= htmlspecialchars($r['email']) ?></small></td>
                        <td><small><?= htmlspecialchars($r['curso'] ?? '—') ?></small></td>
                        <td>
                            <strong><?= htmlspecialchars($r['af_code']) ?></strong>
                            <?php if ($r['status'] === 'ok'): ?>
                                <?= $r['grupo_creado'] ? '<span class="badge-new">Nuevo</span>' : '<span class="badge-exists">Ya existía</span>' ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($r['status'] === 'ok'): ?>
                                <a href="/course/view.php?id=<?= $r['course_id'] ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-external-link-alt"></i> Ver curso
                                </a>
                            <?php else: ?>
                                <small class="text-danger"><?= htmlspecialchars($r['msg']) ?></small>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">ℹ️ Referencia — Cursos e2y Commerce 2026</div>
        <div class="card-body p-0">
            <table class="table table-sm mb-0">
                <thead class="thead-light">
                    <tr><th>Alumno</th><th>Email</th><th>Course ID</th><th>Código AF</th><th>URL</th></tr>
                </thead>
                <tbody>
                    <tr><td>Adrián Barrena</td><td>adrian.barrena@e2ycommerce.com</td><td>3110</td><td>AF002-01</td><td><a href="/course/view.php?id=3110" target="_blank">→</a></td></tr>
                    <tr><td>Andrea Landa</td><td>andrea.landa@e2ycommerce.com</td><td>3112</td><td>AF001-01</td><td><a href="/course/view.php?id=3112" target="_blank">→</a></td></tr>
                    <tr><td>Roberto Gotor</td><td>roberto.gotor@e2ycommerce.com</td><td>3111</td><td>AF002-02</td><td><a href="/course/view.php?id=3111" target="_blank">→</a></td></tr>
                    <tr><td>Francisco Sánchez</td><td>francisco.sanchez@e2ycommerce.com</td><td>3113</td><td>AF003-01</td><td><a href="/course/view.php?id=3113" target="_blank">→</a></td></tr>
                    <tr><td>Nieves Sancho</td><td>nieves.sancho@e2ycommerce.com</td><td>3114</td><td>AF004-01</td><td><a href="/course/view.php?id=3114" target="_blank">→</a></td></tr>
                    <tr><td>José Tomás Morán</td><td>jose.moran@e2ycommerce.com</td><td>3129</td><td>AF005-01</td><td><a href="/course/view.php?id=3129" target="_blank">→</a></td></tr>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
function setModo(modo) {
    document.getElementById('modo_input').value = modo;
    document.getElementById('panel-individual').style.display = modo === 'individual' ? '' : 'none';
    document.getElementById('panel-csv').style.display = modo === 'csv' ? '' : 'none';
    document.getElementById('tab-individual').classList.toggle('active', modo === 'individual');
    document.getElementById('tab-csv').classList.toggle('active', modo === 'csv');
    return false;
}
</script>
</body>
</html>
